<?php
require_once __DIR__ . '/../includes/db.php';

if (empty($_SESSION['admin_id'])) {
    redirect(SITE_URL . '/admin/login.php');
}

/* Stats */
$total_students  = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$total_pending   = (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status='pending'")->fetchColumn();
$total_paid      = (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status='approved'")->fetchColumn();
$active_subs     = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE subscription_end > NOW()")->fetchColumn();
$total_questions = (int)$pdo->query('SELECT COUNT(*) FROM questions')->fetchColumn();
$total_subjects  = (int)$pdo->query('SELECT COUNT(*) FROM subjects')->fetchColumn();

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-5" style="max-width:1100px">

  <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <h2 class="fw-bold mb-0" style="color:#0C1E7F">🛡️ Admin Dashboard</h2>
    <a href="<?= SITE_URL ?>/admin/logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
  </div>

  <p class="text-muted mb-4">
    Welcome, <b><?= e($_SESSION['admin_name'] ?? 'Admin') ?></b>.
  </p>

  <!-- STATS -->
  <div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
      <div class="card p-3 border-0 shadow-sm" style="border-radius:14px">
        <div class="small text-muted">Total Students</div>
        <div class="fs-2 fw-bold" style="color:#0C1E7F"><?= $total_students ?></div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card p-3 border-0 shadow-sm" style="border-radius:14px">
        <div class="small text-muted">Active Subscriptions</div>
        <div class="fs-2 fw-bold text-success"><?= $active_subs ?></div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card p-3 border-0 shadow-sm" style="border-radius:14px">
        <div class="small text-muted">Pending Payments</div>
        <div class="fs-2 fw-bold text-warning"><?= $total_pending ?></div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card p-3 border-0 shadow-sm" style="border-radius:14px">
        <div class="small text-muted">Approved Payments</div>
        <div class="fs-2 fw-bold text-primary"><?= $total_paid ?></div>
      </div>
    </div>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
      <div class="card p-3 border-0 shadow-sm" style="border-radius:14px">
        <div class="small text-muted">Total Questions</div>
        <div class="fs-4 fw-bold" style="color:#0C1E7F"><?= number_format($total_questions) ?></div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card p-3 border-0 shadow-sm" style="border-radius:14px">
        <div class="small text-muted">Total Subjects</div>
        <div class="fs-4 fw-bold" style="color:#3A7728"><?= $total_subjects ?></div>
      </div>
    </div>
  </div>

  <!-- QUICK ACTIONS -->
  <h5 class="fw-bold mb-3" style="color:#0C1E7F">⚡ Quick Actions</h5>

  <div class="row g-3">

    <!-- Payments -->
    <div class="col-md-4">
      <a href="<?= SITE_URL ?>/admin/payments.php"
         class="card p-4 text-decoration-none shadow-sm h-100"
         style="border-radius:16px;border:2px solid #e5e7eb">
        <div class="fs-1">💳</div>
        <div class="fw-bold mt-2" style="color:#0C1E7F">Payment Approvals</div>
        <div class="small text-muted">
          Review and approve Wave/Afrimoney/QMoney payments.
        </div>
        <?php if ($total_pending > 0): ?>
          <span class="badge bg-warning text-dark mt-2 align-self-start">
            <?= $total_pending ?> pending
          </span>
        <?php endif; ?>
      </a>
    </div>

    <!-- Students -->
    <div class="col-md-4">
      <a href="<?= SITE_URL ?>/admin/students.php"
         class="card p-4 text-decoration-none shadow-sm h-100"
         style="border-radius:16px;border:2px solid #e5e7eb">
        <div class="fs-1">👥</div>
        <div class="fw-bold mt-2" style="color:#0C1E7F">Students</div>
        <div class="small text-muted">
          View, cancel subscriptions, and delete students.
        </div>
      </a>
    </div>

    <!-- Subjects -->
    <div class="col-md-4">
      <a href="<?= SITE_URL ?>/admin/subjects.php"
         class="card p-4 text-decoration-none shadow-sm h-100"
         style="border-radius:16px;border:2px solid #e5e7eb">
        <div class="fs-1">📚</div>
        <div class="fw-bold mt-2" style="color:#0C1E7F">Subjects</div>
        <div class="small text-muted">
          Add or edit subjects that students can unlock.
        </div>
      </a>
    </div>

    <!-- All Questions -->
    <div class="col-md-4">
      <a href="<?= SITE_URL ?>/admin/questions.php"
         class="card p-4 text-decoration-none shadow-sm h-100"
         style="border-radius:16px;border:2px solid #e5e7eb">
        <div class="fs-1">❓</div>
        <div class="fw-bold mt-2" style="color:#0C1E7F">All Questions</div>
        <div class="small text-muted">
          Browse, filter, import and delete questions.
        </div>
        <span class="badge bg-primary mt-2 align-self-start">
          <?= number_format($total_questions) ?> total
        </span>
      </a>
    </div>

    <!-- Add Question Manually -->
    <div class="col-md-4">
      <a href="<?= SITE_URL ?>/admin/add_question.php"
         class="card p-4 text-decoration-none shadow-sm h-100"
         style="border-radius:16px;border:2px solid #3A7728;background:linear-gradient(135deg,#fff,#f0fdf4)">
        <div class="fs-1">➕</div>
        <div class="fw-bold mt-2" style="color:#3A7728">Add Question Manually</div>
        <div class="small text-muted">
          Write a question and post it to one or more grades at once.
        </div>
      </a>
    </div>

    <!-- Fix Subjects -->
    <div class="col-md-4">
      <a href="<?= SITE_URL ?>/admin/fix_subjects.php"
         class="card p-4 text-decoration-none shadow-sm h-100"
         style="border-radius:16px;border:2px solid #d97706;background:linear-gradient(135deg,#fff,#fef9c3)">
        <div class="fs-1">🔧</div>
        <div class="fw-bold mt-2" style="color:#78350f">Fix Subjects</div>
        <div class="small" style="color:#78350f">
          Move questions that ended up in the wrong subject.
        </div>
      </a>
    </div>

    <!-- Logout -->
    <div class="col-md-4">
      <a href="<?= SITE_URL ?>/admin/logout.php"
         class="card p-4 text-decoration-none shadow-sm h-100"
         style="border-radius:16px;border:2px solid #e5e7eb">
        <div class="fs-1">🚪</div>
        <div class="fw-bold mt-2" style="color:#CE1126">Logout</div>
        <div class="small text-muted">
          End your admin session.
        </div>
      </a>
    </div>

  </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>