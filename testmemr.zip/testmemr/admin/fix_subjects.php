<?php
require_once __DIR__ . '/../includes/db.php';

if (empty($_SESSION['admin_id'])) {
    redirect(SITE_URL . '/admin/login.php');
}

$msg = '';
$msg_type = 'info';

/* ============================================================
   HANDLE MOVE ACTION
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'move') {

    $qids   = $_POST['question_ids'] ?? [];
    $target = (int)($_POST['target_subject'] ?? 0);

    if (empty($qids) || $target <= 0) {
        flash('Select at least one question and a target subject.', 'danger');
        redirect(SITE_URL . '/admin/fix_subjects.php?filter_subject=' . (int)($_POST['filter_subject'] ?? 0));
    }

    /* Verify the target subject exists */
    $chk = $pdo->prepare('SELECT id FROM subjects WHERE id = ? LIMIT 1');
    $chk->execute([$target]);

    if (!$chk->fetch()) {
        flash('Target subject not found.', 'danger');
        redirect(SITE_URL . '/admin/fix_subjects.php');
    }

    /* Move them */
    $ids = array_map('intval', $qids);
    $in  = implode(',', array_fill(0, count($ids), '?'));

    try {
        $st = $pdo->prepare("UPDATE questions SET subject_id = ? WHERE id IN ($in)");
        $st->execute(array_merge([$target], $ids));
        $moved = $st->rowCount();

        flash("✅ Moved $moved question(s) successfully.");
    } catch (Exception $e) {
        flash('Error: ' . $e->getMessage(), 'danger');
    }

    redirect(SITE_URL . '/admin/fix_subjects.php?filter_subject=' . (int)($_POST['filter_subject'] ?? 0));
}

/* ============================================================
   LOAD SUBJECTS
   ============================================================ */
$subjects = [];
try {
    $sub_cols = $pdo->query('DESCRIBE subjects')->fetchAll(PDO::FETCH_COLUMN);
    $S_GRADE  = in_array('class_level', $sub_cols, true) ? 'class_level'
              : (in_array('grade', $sub_cols, true) ? 'grade' : null);
    $S_NAME   = in_array('name', $sub_cols, true) ? 'name' : 'id';

    $sql_sub  = "SELECT id, $S_NAME AS name" . ($S_GRADE ? ", $S_GRADE AS grade" : "")
              . " FROM subjects ORDER BY " . ($S_GRADE ? "$S_GRADE, " : "") . "$S_NAME";
    $subjects = $pdo->query($sql_sub)->fetchAll();
} catch (Exception $e) { $subjects = []; }

/* ============================================================
   FILTER
   ============================================================ */
$filter_subject = (int)($_GET['filter_subject'] ?? 0);
$filter_grade   = trim($_GET['filter_grade'] ?? '');

/* Build query */
$sql    = 'SELECT q.id, q.question, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_index, q.subject_id,
                  s.name AS subject_name
           FROM questions q
           LEFT JOIN subjects s ON s.id = q.subject_id';

$where  = [];
$params = [];

if ($filter_subject > 0) {
    $where[]  = 'q.subject_id = ?';
    $params[] = $filter_subject;
}

if (!empty($filter_grade)) {
    $where[]  = '(s.class_level = ? OR s.grade = ?)';
    $params[] = $filter_grade;
    $params[] = $filter_grade;
}

if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' ORDER BY q.id DESC LIMIT 300';

$st = $pdo->prepare($sql);
$st->execute($params);
$questions = $st->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:1200px">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="fw-bold mb-0" style="color:#0C1E7F">🔧 Fix Question Subjects</h3>
    <a href="<?= SITE_URL ?>/admin/dashboard.php" class="btn btn-outline-secondary btn-sm">
      ← Dashboard
    </a>
  </div>

  <?php if ($msg): ?>
    <div class="alert alert-<?= $msg_type ?>"><?= e($msg) ?></div>
  <?php endif; ?>

  <!-- FILTER -->
  <div class="card p-3 mb-4 shadow-sm" style="border-radius:14px">
    <form method="get" class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label small fw-bold">Subject</label>
        <select name="filter_subject" class="form-select">
          <option value="">All subjects</option>
          <?php foreach ($subjects as $s): ?>
            <option value="<?= (int)$s['id'] ?>"
                    <?= $filter_subject === (int)$s['id'] ? 'selected' : '' ?>>
              <?= e($s['name']) ?><?= !empty($s['grade']) ? ' (' . e($s['grade']) . ')' : '' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4">
        <label class="form-label small fw-bold">Grade</label>
        <select name="filter_grade" class="form-select">
          <option value="">All grades</option>
          <?php foreach (CLASS_LEVELS as $g): ?>
            <option value="<?= e($g) ?>" <?= $filter_grade === $g ? 'selected' : '' ?>>
              <?= e($g) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4 d-flex gap-2">
        <button class="btn btn-primary flex-grow-1">🔍 Filter</button>
        <a href="<?= SITE_URL ?>/admin/fix_subjects.php" class="btn btn-outline-secondary">Reset</a>
      </div>
    </form>
  </div>

  <!-- INSTRUCTIONS -->
  <div class="alert alert-info">
    <b>How to use:</b>
    <ol class="mb-0 small">
      <li>Tick the questions that are in the <b>wrong</b> subject</li>
      <li>Pick the <b>correct subject</b> from the dropdown at the bottom</li>
      <li>Click <b>🚚 Move Selected</b></li>
    </ol>
  </div>

  <form method="post">
    <input type="hidden" name="action" value="move">
    <input type="hidden" name="filter_subject" value="<?= (int)$filter_subject ?>">

    <div class="card p-3 mb-3 shadow-sm" style="border-radius:14px">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
          <b><?= count($questions) ?></b> question(s) shown
          <?php if ($filter_subject > 0): ?>
            — filtered by <b><?= e($subjects[array_search($filter_subject, array_column($subjects, 'id'))]['name'] ?? '') ?></b>
          <?php endif; ?>
        </div>
        <div class="d-flex gap-2 flex-wrap">
          <button type="button" class="btn btn-sm btn-outline-primary" onclick="checkAll(true)">
            ✅ Check All
          </button>
          <button type="button" class="btn btn-sm btn-outline-secondary" onclick="checkAll(false)">
            ☐ Uncheck All
          </button>
        </div>
      </div>
    </div>

    <?php if (empty($questions)): ?>
      <div class="alert alert-secondary">No questions found.</div>
    <?php else: ?>
      <?php foreach ($questions as $q):
        $qid    = (int)$q['id'];
        $corr   = (int)($q['correct_index'] ?? 0);
      ?>
        <div class="card p-3 mb-2 border-0 shadow-sm" id="qcard-<?= $qid ?>">
          <div class="d-flex gap-3">

            <!-- Checkbox -->
            <div class="flex-shrink-0 pt-1">
              <input type="checkbox" name="question_ids[]" value="<?= $qid ?>"
                     class="form-check-input q-check"
                     style="width:22px;height:22px;cursor:pointer">
            </div>

            <!-- Content -->
            <div class="flex-grow-1">
              <div class="small text-muted mb-1">
                <span class="badge bg-secondary">#<?= $qid ?></span>
                <span class="badge bg-primary"><?= e($q['subject_name'] ?? '—') ?></span>
              </div>
              <div class="fw-bold mb-2"><?= e($q['question']) ?></div>
              <div class="small">
                <div>A. <?= e($q['option_a']) ?></div>
                <div>B. <?= e($q['option_b']) ?></div>
                <div>C. <?= e($q['option_c']) ?></div>
                <div>D. <?= e($q['option_d']) ?></div>
              </div>
              <div class="small text-success mt-1">
                ✓ Correct: <?= ['A','B','C','D'][$corr] ?? '?' ?>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <!-- MOVE CONTROL (sticky bottom) -->
    <?php if (!empty($questions)): ?>
      <div class="position-sticky bottom-0 mt-3" style="z-index:10">
        <div class="card p-3 shadow-lg border-2 border-primary"
             style="border-radius:14px;background:#fff">
          <div class="row g-2 align-items-end">
            <div class="col-md-6">
              <label class="form-label fw-bold">🎯 Move selected questions to:</label>
              <select name="target_subject" class="form-select form-select-lg" required>
                <option value="">-- Choose target subject --</option>
                <?php foreach ($subjects as $s): ?>
                  <option value="<?= (int)$s['id'] ?>">
                    <?= e($s['name']) ?><?= !empty($s['grade']) ? ' (' . e($s['grade']) . ')' : '' ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <button type="submit" class="btn btn-primary btn-lg w-100 fw-bold"
                      onclick="return confirmMove();">
                🚚 Move Selected
              </button>
            </div>
          </div>
          <div class="small text-muted mt-2 text-center">
            Selected: <b id="selCount">0</b> question(s)
          </div>
        </div>
      </div>
    <?php endif; ?>
  </form>

</div>

<script>
function checkAll(state) {
  document.querySelectorAll('.q-check').forEach(function (cb) {
    cb.checked = state;
  });
  updateCount();
}

function updateCount() {
  var n = document.querySelectorAll('.q-check:checked').length;
  var el = document.getElementById('selCount');
  if (el) el.textContent = n;
}

function confirmMove() {
  var n = document.querySelectorAll('.q-check:checked').length;
  if (n === 0) {
    alert('Please select at least one question.');
    return false;
  }
  return confirm('Move ' + n + ' question(s) to the new subject?');
}

document.querySelectorAll('.q-check').forEach(function (cb) {
  cb.addEventListener('change', updateCount);
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>