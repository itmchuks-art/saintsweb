<?php
require_once __DIR__ . '/../includes/db.php';

if (empty($_SESSION['admin_id'])) {
    redirect(SITE_URL . '/admin/login.php');
}

$msg  = '';
$type = 'info';

/* ============================================================
   HANDLE APPROVE / REJECT
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $payment_id = (int)($_POST['payment_id'] ?? 0);
    $action     = $_POST['action'] ?? '';

    if ($payment_id > 0 && in_array($action, ['approve', 'reject'], true)) {

        /* Load payment */
        $st = $pdo->prepare('SELECT * FROM payments WHERE id = ? LIMIT 1');
        $st->execute([$payment_id]);
        $payment = $st->fetch();

        if (!$payment) {
            flash('Payment not found.', 'danger');
            redirect(SITE_URL . '/admin/payments.php');
        }

        /* ---------- REJECT ---------- */
        if ($action === 'reject') {
            $pdo->prepare('UPDATE payments SET status = ? WHERE id = ?')
                ->execute(['rejected', $payment_id]);

            flash('❌ Payment #' . $payment_id . ' rejected.', 'warning');
            redirect(SITE_URL . '/admin/payments.php');
        }

        /* ---------- APPROVE ---------- */
        $plan = PLANS[$payment['plan']] ?? null;
        if (!$plan) {
            flash('Unknown plan for this payment.', 'danger');
            redirect(SITE_URL . '/admin/payments.php');
        }

        /* Load user */
        $user_st = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $user_st->execute([(int)$payment['user_id']]);
        $u = $user_st->fetch();

        if (!$u) {
            flash('User not found.', 'danger');
            redirect(SITE_URL . '/admin/payments.php');
        }

        /* ---------- Compute new subscription_end ---------- */
        $base = (!empty($u['subscription_end']) && strtotime($u['subscription_end']) > time())
            ? strtotime($u['subscription_end'])
            : time();

        $new_end = date('Y-m-d H:i:s', $base + ($plan['days'] * 86400));

        /* ---------- MERGE grades with existing ---------- */
        $existing_grades = [];
        if (!empty($u['subscribed_grades'])) {
            $existing_grades = array_map('trim', explode(',', $u['subscribed_grades']));
            $existing_grades = array_values(array_filter($existing_grades, fn($g) => $g !== ''));
        }

        $new_grades = [];
        if (!empty($payment['subscribed_grades'])) {
            $new_grades = array_map('trim', explode(',', $payment['subscribed_grades']));
            $new_grades = array_values(array_filter($new_grades, fn($g) => $g !== ''));
        }

        /* all_* plans wipe and replace with ALL */
        if ($plan['type'] === 'all') {
            $all_grades  = CLASS_LEVELS;
        } else {
            $all_grades  = array_values(array_unique(array_merge($existing_grades, $new_grades)));
        }

        $final_grades = implode(',', $all_grades);

        /* ---------- MERGE subjects with existing ---------- */
        $existing_subjects = [];
        if (!empty($u['subscribed_subjects'])) {
            $existing_subjects = array_map('intval', explode(',', $u['subscribed_subjects']));
            $existing_subjects = array_values(array_filter($existing_subjects, fn($s) => $s > 0));
        }

        $new_subjects = [];
        if (!empty($payment['subscribed_subjects'])) {
            $new_subjects = array_map('intval', explode(',', $payment['subscribed_subjects']));
            $new_subjects = array_values(array_filter($new_subjects, fn($s) => $s > 0));
        }

        $all_subjects   = array_values(array_unique(array_merge($existing_subjects, $new_subjects)));
        $final_subjects = $all_subjects ? implode(',', $all_subjects) : null;

        /* ---------- Update user ---------- */
        $pdo->prepare('UPDATE users
            SET subscription_plan    = ?,
                subscription_end     = ?,
                subscribed_grades    = ?,
                subscribed_subjects  = ?
            WHERE id = ?')
            ->execute([
                $payment['plan'],
                $new_end,
                $final_grades ?: null,
                $final_subjects,
                (int)$u['id'],
            ]);

        /* ---------- Mark payment approved ---------- */
        $pdo->prepare('UPDATE payments SET status = ?, approved_at = NOW() WHERE id = ?')
            ->execute(['approved', $payment_id]);

        /* ---------- Success message ---------- */
        $grades_added = implode(' · ', $all_grades);
        flash('✅ Payment #' . $payment_id . ' approved. Student now has: ' . $grades_added);
        redirect(SITE_URL . '/admin/payments.php');
    }
}

/* ============================================================
   LIST PAYMENTS
   ============================================================ */
$filter = $_GET['filter'] ?? 'pending';
$allowed_filters = ['all', 'pending', 'approved', 'rejected'];

if (!in_array($filter, $allowed_filters, true)) $filter = 'pending';

$sql = 'SELECT p.*, u.name AS user_name, u.phone AS user_phone, u.grade AS user_grade
        FROM payments p
        LEFT JOIN users u ON u.id = p.user_id';

if ($filter !== 'all') {
    $sql .= ' WHERE p.status = ? ORDER BY p.id DESC LIMIT 200';
    $st = $pdo->prepare($sql);
    $st->execute([$filter]);
} else {
    $sql .= ' ORDER BY p.id DESC LIMIT 200';
    $st = $pdo->query($sql);
}
$payments = $st->fetchAll();

$counts = [
    'pending'  => (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status='pending'")->fetchColumn(),
    'approved' => (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status='approved'")->fetchColumn(),
    'rejected' => (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status='rejected'")->fetchColumn(),
];

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:1100px">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="fw-bold mb-0" style="color:#0C1E7F">💳 Payment Approvals</h3>
    <a href="<?= SITE_URL ?>/admin/dashboard.php" class="btn btn-outline-secondary btn-sm">
      ← Dashboard
    </a>
  </div>

  <?php if ($msg): ?>
    <div class="alert alert-<?= $type ?>"><?= e($msg) ?></div>
  <?php endif; ?>

  <!-- Filter tabs -->
  <ul class="nav nav-pills mb-3">
    <li class="nav-item me-2">
      <a class="nav-link <?= $filter === 'pending'  ? 'active' : '' ?>"
         href="?filter=pending"
         style="<?= $filter === 'pending'  ? 'background:#d97706;color:#fff' : 'color:#d97706;border:1px solid #d97706' ?>">
        ⏳ Pending (<?= $counts['pending'] ?>)
      </a>
    </li>
    <li class="nav-item me-2">
      <a class="nav-link <?= $filter === 'approved' ? 'active' : '' ?>"
         href="?filter=approved"
         style="<?= $filter === 'approved' ? 'background:#16a34a;color:#fff' : 'color:#16a34a;border:1px solid #16a34a' ?>">
        ✅ Approved (<?= $counts['approved'] ?>)
      </a>
    </li>
    <li class="nav-item me-2">
      <a class="nav-link <?= $filter === 'rejected' ? 'active' : '' ?>"
         href="?filter=rejected"
         style="<?= $filter === 'rejected' ? 'background:#CE1126;color:#fff' : 'color:#CE1126;border:1px solid #CE1126' ?>">
        ❌ Rejected (<?= $counts['rejected'] ?>)
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?= $filter === 'all'      ? 'active' : '' ?>"
         href="?filter=all"
         style="<?= $filter === 'all'      ? 'background:#0C1E7F;color:#fff' : 'color:#0C1E7F;border:1px solid #0C1E7F' ?>">
        📋 All
      </a>
    </li>
  </ul>

  <?php if (empty($payments)): ?>
    <div class="alert alert-secondary">No payments in this list.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-hover align-middle bg-white shadow-sm"
             style="border-radius:12px;overflow:hidden">
        <thead style="background:#0C1E7F;color:#fff">
          <tr>
            <th>#</th>
            <th>Student</th>
            <th>Plan</th>
            <th>Amount</th>
            <th>Method</th>
            <th>Reference</th>
            <th>Proof</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($payments as $p):
            $label = PLANS[$p['plan']]['label'] ?? $p['plan'];
            $badge =
              $p['status'] === 'approved' ? 'success' :
              ($p['status'] === 'pending' ? 'warning text-dark' :
              ($p['status'] === 'rejected' ? 'danger' : 'secondary'));
          ?>
            <tr>
              <td>#<?= (int)$p['id'] ?></td>
              <td>
                <div class="fw-bold"><?= e($p['user_name'] ?? '—') ?></div>
                <div class="small text-muted"><?= e($p['user_phone'] ?? '') ?></div>
                <?php if (!empty($p['user_grade'])): ?>
                  <div class="small text-primary">Grade: <?= e($p['user_grade']) ?></div>
                <?php endif; ?>
              </td>
              <td>
                <span class="small"><?= e($label) ?></span>
                <?php if (!empty($p['subscribed_grades'])): ?>
                  <div class="small text-muted">
                    📚 <?= e($p['subscribed_grades']) ?>
                  </div>
                <?php endif; ?>
                <?php if (!empty($p['subscribed_subjects'])): ?>
                  <div class="small text-muted">
                    📖 Subject ID(s): <?= e($p['subscribed_subjects']) ?>
                  </div>
                <?php endif; ?>
              </td>
              <td class="fw-bold">D<?= (int)$p['amount'] ?></td>
              <td><?= e($p['method']) ?></td>
              <td><code class="small"><?= e($p['reference']) ?></code></td>
              <td>
                <?php if (!empty($p['screenshot']) && file_exists(__DIR__ . '/../' . $p['screenshot'])): ?>
                  <a href="<?= SITE_URL ?>/<?= e($p['screenshot']) ?>" target="_blank">
                    <img src="<?= SITE_URL ?>/<?= e($p['screenshot']) ?>"
                         style="width:60px;height:60px;object-fit:cover;border-radius:8px">
                  </a>
                <?php else: ?>
                  <span class="text-muted small">—</span>
                <?php endif; ?>
              </td>
              <td>
                <span class="badge bg-<?= $badge ?>"><?= e($p['status']) ?></span>
              </td>
              <td>
                <?php if ($p['status'] === 'pending'): ?>
                  <form method="post" class="d-inline"
                        onsubmit="return confirm('Approve this payment?');">
                    <input type="hidden" name="payment_id" value="<?= (int)$p['id'] ?>">
                    <input type="hidden" name="action" value="approve">
                    <button class="btn btn-sm btn-success">✅ Approve</button>
                  </form>

                  <form method="post" class="d-inline"
                        onsubmit="return confirm('Reject this payment?');">
                    <input type="hidden" name="payment_id" value="<?= (int)$p['id'] ?>">
                    <input type="hidden" name="action" value="reject">
                    <button class="btn btn-sm btn-outline-danger">❌ Reject</button>
                  </form>
                <?php else: ?>
                  <span class="text-muted small">
                    <?= e(fmt_date($p['approved_at'] ?? $p['created_at'] ?? null)) ?>
                  </span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>