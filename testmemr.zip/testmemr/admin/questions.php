<?php
require_once __DIR__ . '/../includes/db.php';

if (empty($_SESSION['admin_id'])) {
    redirect(SITE_URL . '/admin/login.php');
}

/* ============================================================
   DETECT COLUMNS
   ============================================================ */
$cols = $pdo->query('DESCRIBE questions')->fetchAll(PDO::FETCH_COLUMN);
$pick = function ($list) use ($cols) {
    foreach ($list as $c) if (in_array($c, $cols, true)) return $c;
    return null;
};

$C_QUESTION   = $pick(['question_text','question','q','text']);
$C_OPT_A      = $pick(['option_a','a']);
$C_OPT_B      = $pick(['option_b','b']);
$C_OPT_C      = $pick(['option_c','c']);
$C_OPT_D      = $pick(['option_d','d']);
$C_CORRECT    = $pick(['correct_option','correct','answer','ans']);
$C_CORRECT_IX = $pick(['correct_index']);
$C_EXPLAIN    = $pick(['explanation','reason','note']);
$C_SUBJECT    = $pick(['subject_id','subject']);

/* ALL grade-like columns */
$GRADE_COLS = [];
foreach (['grade','class_level','exam_type'] as $gc) {
    if (in_array($gc, $cols, true)) $GRADE_COLS[] = $gc;
}

$use_index = ($C_CORRECT_IX !== null);

function to_db_answer($val, bool $use_index): ?string {
    $val = trim((string)$val);
    if ($val === '') return null;
    if (is_numeric($val)) {
        $n = (int)$val;
        if ($n >= 0 && $n <= 3) return $use_index ? (string)$n : ['A','B','C','D'][$n];
        return null;
    }
    $val = strtoupper($val);
    if (in_array($val, ['A','B','C','D'], true)) {
        if ($use_index) return (string)['A'=>0,'B'=>1,'C'=>2,'D'=>3][$val];
        return $val;
    }
    return null;
}

function db_to_letter($val): string {
    if ($val === null || $val === '') return '';
    if (is_numeric($val)) return [0=>'A',1=>'B',2=>'C',3=>'D'][(int)$val] ?? '';
    return in_array(strtoupper($val), ['A','B','C','D'], true) ? strtoupper($val) : '';
}

$csv_report = null;

/* ============================================================
   HANDLE POST
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    /* ---------- CSV IMPORT ---------- */
    if ($action === 'csv') {
        if (empty($_FILES['csv']['tmp_name'])) {
            flash('Upload a CSV file.', 'danger');
            redirect(SITE_URL . '/admin/questions.php');
        }

        $fh = fopen($_FILES['csv']['tmp_name'], 'r');
        if (!$fh) {
            flash('Could not read file.', 'danger');
            redirect(SITE_URL . '/admin/questions.php');
        }

        $header = array_map(fn($h) => strtolower(trim($h)), fgetcsv($fh));

        /* Build INSERT — include EVERY grade column */
        $fields = [
            $C_QUESTION => null,
            $C_OPT_A    => null,
            $C_OPT_B    => null,
            $C_OPT_C    => null,
            $C_OPT_D    => null,
        ];
        if ($C_SUBJECT) $fields[$C_SUBJECT] = null;
        foreach ($GRADE_COLS as $gc) $fields[$gc] = null;
        if ($use_index) $fields[$C_CORRECT_IX] = null;
        else            $fields[$C_CORRECT]    = null;
        if ($C_EXPLAIN) $fields[$C_EXPLAIN] = null;

        $insert_cols  = array_keys($fields);
        $placeholders = implode(',', array_fill(0, count($insert_cols), '?'));
        $ins = $pdo->prepare('INSERT INTO questions (' . implode(',', $insert_cols) . ") VALUES ($placeholders)");

        $imported = 0;
        $skipped  = 0;
        $errors   = [];

        while (($row = fgetcsv($fh)) !== false) {
            if (count($row) < 5) continue;

            $data = [];
            foreach ($header as $i => $col) {
                $data[$col] = trim((string)($row[$i] ?? ''));
            }

            $q = $data['question'] ?? $data['question_text'] ?? '';
            $a = $data['option_a'] ?? $data['a'] ?? '';
            $b = $data['option_b'] ?? $data['b'] ?? '';
            $c = $data['option_c'] ?? $data['c'] ?? '';
            $d = $data['option_d'] ?? $data['d'] ?? '';

            $ansRaw = $data['correct_index'] ?? $data['correct'] ?? $data['answer'] ?? '';
            $db_ans = to_db_answer($ansRaw, $use_index);

            $sub_id = (int)($data['subject_id'] ?? 0);
            $sub_nm = trim($data['subject'] ?? '');

            /* Grade — read from ANY column */
            $grade = '';
            foreach (['class_level','grade','exam_type'] as $gk) {
                if (!empty($data[$gk])) { $grade = $data[$gk]; break; }
            }
            $exp = $data['explanation'] ?? '';

            if ($q === '' || $a === '' || $b === '' || $c === '' || $d === '') { $skipped++; continue; }
            if ($db_ans === null) { $skipped++; continue; }
            if ($sub_id === 0 && $sub_nm === '') { $skipped++; continue; }
            if ($grade === '') { $skipped++; continue; }

            if ($sub_id === 0 && $sub_nm !== '') {
                $st = $pdo->prepare('SELECT id FROM subjects WHERE LOWER(name) = LOWER(?) LIMIT 1');
                $st->execute([$sub_nm]);
                $sub_id = (int)$st->fetchColumn();
                if ($sub_id === 0) { $skipped++; continue; }
            }

            $values = [
                $C_QUESTION => $q,
                $C_OPT_A    => $a,
                $C_OPT_B    => $b,
                $C_OPT_C    => $c,
                $C_OPT_D    => $d,
            ];
            if ($C_SUBJECT) $values[$C_SUBJECT] = $sub_id;
            /* Fill EVERY grade column with same value */
            foreach ($GRADE_COLS as $gc) $values[$gc] = $grade;
            if ($use_index) $values[$C_CORRECT_IX] = $db_ans;
            else            $values[$C_CORRECT]    = $db_ans;
            if ($C_EXPLAIN) $values[$C_EXPLAIN] = $exp;

            $final = [];
            foreach ($insert_cols as $k) $final[] = $values[$k] ?? null;

            try {
                $ins->execute($final);
                $imported++;
            } catch (Exception $e) {
                $errors[] = $e->getMessage();
                $skipped++;
            }
        }
        fclose($fh);

        $csv_report = ['imported' => $imported, 'skipped' => $skipped, 'errors' => $errors];
        flash("✅ Imported $imported question(s). Skipped $skipped.");
    }

    /* ---------- DELETE ONE ---------- */
    elseif ($action === 'delete') {
        $qid = (int)($_POST['question_id'] ?? 0);
        if ($qid > 0) {
            $pdo->prepare('DELETE FROM questions WHERE id = ?')->execute([$qid]);
            flash('🗑️ Deleted.');
        }
        redirect(SITE_URL . '/admin/questions.php');
    }

    /* ---------- DELETE ALL FILTERED ---------- */
    elseif ($action === 'delete_filtered') {
        $del_subject = (int)($_POST['del_subject'] ?? 0);
        $del_grade   = trim($_POST['del_grade'] ?? '');

        if ($del_subject > 0 || $del_grade !== '') {
            $where = []; $params = [];

            if ($C_SUBJECT && $del_subject > 0) {
                $where[] = $C_SUBJECT . ' = ?';
                $params[] = $del_subject;
            }
            if ($del_grade !== '' && !empty($GRADE_COLS)) {
                $gc_conds = [];
                foreach ($GRADE_COLS as $gc) {
                    $gc_conds[] = "$gc = ?";
                    $params[] = $del_grade;
                }
                $where[] = '(' . implode(' OR ', $gc_conds) . ')';
            }

            if ($where) {
                $st = $pdo->prepare('DELETE FROM questions WHERE ' . implode(' AND ', $where));
                $st->execute($params);
                flash('🗑️ Deleted ' . $st->rowCount() . ' question(s).', 'warning');
            }
        }
        redirect(SITE_URL . '/admin/questions.php');
    }
}

/* ============================================================
   LOAD SUBJECTS
   ============================================================ */
$subjects = [];
try {
    $sc = $pdo->query('DESCRIBE subjects')->fetchAll(PDO::FETCH_COLUMN);
    $S_NAME = in_array('name', $sc, true) ? 'name' : 'id';
    $S_GRD  = in_array('class_level', $sc, true) ? 'class_level'
            : (in_array('grade', $sc, true) ? 'grade' : null);

    $sql = "SELECT id, $S_NAME AS name" . ($S_GRD ? ", $S_GRD AS grade" : "")
         . " FROM subjects ORDER BY " . ($S_GRD ? "$S_GRD, " : "") . "$S_NAME";
    $subjects = $pdo->query($sql)->fetchAll();
} catch (Exception $e) { $subjects = []; }

/* ============================================================
   FILTER + BUILD QUERY
   ============================================================ */
$filter_subject = (int)($_GET['subject'] ?? 0);
$filter_grade   = trim($_GET['grade'] ?? '');
$filter_search  = trim($_GET['q'] ?? '');

$sql = 'SELECT q.*, s.name AS subject_name FROM questions q'
     . ($C_SUBJECT ? ' LEFT JOIN subjects s ON s.id = q.' . $C_SUBJECT : '');
$where = []; $params = [];

if ($C_SUBJECT && $filter_subject > 0) {
    $where[] = 'q.' . $C_SUBJECT . ' = ?';
    $params[] = $filter_subject;
}

/* Grade filter — check ALL grade columns */
if ($filter_grade !== '' && in_array($filter_grade, CLASS_LEVELS, true) && !empty($GRADE_COLS)) {
    $gc_conds = [];
    foreach ($GRADE_COLS as $gc) {
        $gc_conds[] = 'q.' . $gc . ' = ?';
        $params[] = $filter_grade;
    }
    $where[] = '(' . implode(' OR ', $gc_conds) . ')';
}

if ($filter_search !== '') {
    $where[] = 'q.' . $C_QUESTION . ' LIKE ?';
    $params[] = '%' . $filter_search . '%';
}

if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' ORDER BY q.id DESC LIMIT 200';

$st = $pdo->prepare($sql);
$st->execute($params);
$questions = $st->fetchAll();

$total = (int)$pdo->query('SELECT COUNT(*) FROM questions')->fetchColumn();

/* Counter for filtered set */
$count_sql = 'SELECT COUNT(*) FROM questions q';
if ($where) $count_sql .= ' WHERE ' . implode(' AND ', $where);
$st2 = $pdo->prepare($count_sql);
$st2->execute($params);
$filtered_count = (int)$st2->fetchColumn();

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:1100px">

  <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <h3 class="fw-bold mb-0" style="color:#0C1E7F">❓ Questions</h3>
    <div class="d-flex gap-2 flex-wrap">
      <a href="<?= SITE_URL ?>/admin/add_question.php" class="btn btn-success btn-sm fw-bold"
         style="background:linear-gradient(135deg,#3A7728,#16a34a);border:none">
        ➕ Add Question Manually
      </a>
      <a href="<?= SITE_URL ?>/admin/fix_subjects.php" class="btn btn-warning btn-sm fw-bold">
        🔧 Fix Subjects
      </a>
      <a href="<?= SITE_URL ?>/admin/dashboard.php" class="btn btn-outline-secondary btn-sm">
        ← Dashboard
      </a>
    </div>
  </div>

  <?php if ($csv_report): ?>
    <div class="alert alert-info">
      <b>✅ Import complete</b> — <?= (int)$csv_report['imported'] ?> imported · <?= (int)$csv_report['skipped'] ?> skipped
      <?php if (!empty($csv_report['errors'])): ?>
        <hr>
        <div class="small">
          <b>Errors (first 5):</b>
          <ul class="mb-0">
            <?php foreach (array_slice($csv_report['errors'], 0, 5) as $er): ?>
              <li><?= e($er) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <!-- CSV IMPORT -->
  <div class="card p-4 shadow-sm mb-4" style="border-radius:16px;border-left:5px solid #3A7728">
    <h5 class="fw-bold" style="color:#3A7728">📤 Import Questions (CSV)</h5>

    <div class="alert alert-secondary small">
      <b>Supported CSV formats:</b><br>
      <code>subject_id, class_level, exam_type, year, question, option_a, option_b, option_c, option_d, correct_index</code>
      <br><br>
      Also: <code>subject, grade, a, b, c, d, correct, explanation</code>
    </div>

    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="action" value="csv">
      <div class="row g-2 align-items-end">
        <div class="col-md-9">
          <label class="form-label fw-bold">CSV file</label>
          <input type="file" name="csv" accept=".csv" class="form-control" required>
        </div>
        <div class="col-md-3">
          <button class="btn btn-success w-100 fw-bold"
                  style="background:linear-gradient(135deg,#3A7728,#16a34a);border:none">
            📤 Import
          </button>
        </div>
      </div>
    </form>
  </div>

  <!-- FILTER -->
  <div class="card p-3 shadow-sm mb-4" style="border-radius:14px">
    <form method="get" class="row g-2 align-items-end">
      <div class="col-md-3">
        <label class="form-label small fw-bold">Subject</label>
        <select name="subject" class="form-select">
          <option value="">All subjects</option>
          <?php foreach ($subjects as $s): ?>
            <option value="<?= (int)$s['id'] ?>" <?= $filter_subject === (int)$s['id'] ? 'selected' : '' ?>>
              <?= e($s['name']) ?><?= !empty($s['grade']) ? ' (' . e($s['grade']) . ')' : '' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label small fw-bold">Grade</label>
        <select name="grade" class="form-select">
          <option value="">All grades</option>
          <?php foreach (CLASS_LEVELS as $g): ?>
            <option value="<?= e($g) ?>" <?= $filter_grade === $g ? 'selected' : '' ?>><?= e($g) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label small fw-bold">Search text</label>
        <input type="text" name="q" class="form-control" value="<?= e($filter_search) ?>"
               placeholder="e.g. water">
      </div>
      <div class="col-md-3 d-flex gap-2">
        <button class="btn btn-primary flex-grow-1">🔍 Filter</button>
        <a href="<?= SITE_URL ?>/admin/questions.php" class="btn btn-outline-secondary">Reset</a>
      </div>
    </form>
  </div>

  <!-- LIST -->
  <div class="card p-4 shadow-sm" style="border-radius:16px">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
      <h5 class="fw-bold mb-0" style="color:#0C1E7F">
        📋 Questions
        <span class="badge bg-secondary"><?= count($questions) ?> shown</span>
        <span class="badge bg-primary"><?= number_format($filtered_count) ?> matched</span>
        <span class="badge bg-light text-dark"><?= number_format($total) ?> total</span>
      </h5>

      <?php if ($filter_subject > 0 || $filter_grade !== ''): ?>
        <form method="post" onsubmit="return confirm('⚠️ Delete ALL filtered questions? This cannot be undone.');">
          <input type="hidden" name="action" value="delete_filtered">
          <input type="hidden" name="del_subject" value="<?= $filter_subject ?>">
          <input type="hidden" name="del_grade" value="<?= e($filter_grade) ?>">
          <button class="btn btn-sm btn-outline-danger">
            🗑️ Delete All Filtered
          </button>
        </form>
      <?php endif; ?>
    </div>

    <?php if (empty($questions)): ?>
      <div class="alert alert-warning mb-0">
        ⚠️ No questions found with these filters.
        <?php if ($filter_grade !== ''): ?>
          <br><small class="text-muted">
            Tip: try removing the grade filter to see if the question exists under a different grade.
          </small>
        <?php endif; ?>
      </div>
    <?php else: ?>
      <?php foreach ($questions as $q):
        $qid = (int)$q['id'];
        $ansVal = null;
        if ($C_CORRECT_IX !== null && isset($q[$C_CORRECT_IX])) $ansVal = $q[$C_CORRECT_IX];
        elseif ($C_CORRECT !== null && isset($q[$C_CORRECT])) $ansVal = $q[$C_CORRECT];
        $corr = db_to_letter($ansVal);

        /* Show first non-empty grade */
        $grade_display = '';
        foreach ($GRADE_COLS as $gc) {
            if (!empty($q[$gc])) { $grade_display = $q[$gc]; break; }
        }
      ?>
        <div class="border rounded-3 p-3 mb-2 bg-white">
          <div class="fw-bold">#<?= $qid ?> — <?= e($q[$C_QUESTION] ?? '') ?></div>
          <div class="small text-muted mb-2">
            <?= e($q['subject_name'] ?? '') ?>
            <?php if ($grade_display): ?> · <?= e($grade_display) ?><?php endif; ?>
          </div>
          <div class="small">
            <div <?= $corr==='A'?'class="fw-bold text-success"':'' ?>>A. <?= e($q[$C_OPT_A] ?? '') ?></div>
            <div <?= $corr==='B'?'class="fw-bold text-success"':'' ?>>B. <?= e($q[$C_OPT_B] ?? '') ?></div>
            <div <?= $corr==='C'?'class="fw-bold text-success"':'' ?>>C. <?= e($q[$C_OPT_C] ?? '') ?></div>
            <div <?= $corr==='D'?'class="fw-bold text-success"':'' ?>>D. <?= e($q[$C_OPT_D] ?? '') ?></div>
          </div>

          <div class="mt-2 d-flex justify-content-end gap-2">
            <a href="<?= SITE_URL ?>/admin/edit_question.php?id=<?= $qid ?>"
               class="btn btn-sm btn-outline-primary">✏️ Edit</a>
            <form method="post" onsubmit="return confirm('Delete this question?');" class="d-inline">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="question_id" value="<?= $qid ?>">
              <button class="btn btn-sm btn-outline-danger">🗑️ Delete</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>