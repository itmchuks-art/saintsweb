<?php
require_once __DIR__ . '/../includes/db.php';

if (empty($_SESSION['admin_id'])) {
    redirect(SITE_URL . '/admin/login.php');
}

/* ============================================================
   HANDLE ACTIONS (delete / cancel subscription)
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $user_id = (int)($_POST['user_id'] ?? 0);
    $action  = $_POST['action'] ?? '';

    if ($user_id > 0) {

        if ($action === 'delete') {
            /* Delete payments first */
            try {
                $pdo->prepare('DELETE FROM payments WHERE user_id = ?')->execute([$user_id]);
            } catch (Exception $e) { }

            /* Delete the user */
            $pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$user_id]);

            flash('🗑️ Student #' . $user_id . ' deleted.');
            redirect(SITE_URL . '/admin/students.php');

        } elseif ($action === 'cancel_sub') {
            $pdo->prepare('UPDATE users
                SET subscription_plan   = NULL,
                    subscription_end    = NULL,
                    subscribed_grades   = NULL,
                    subscribed_subjects = NULL
                WHERE id = ?')
                ->execute([$user_id]);

            flash('🚫 Subscription cancelled for student #' . $user_id . '.');
            redirect(SITE_URL . '/admin/students.php');
        }
    }
}

/* ============================================================
   SEARCH + LIST
   ============================================================ */
$q = trim($_GET['q'] ?? '');

if ($q !== '') {
    $st = $pdo->prepare('SELECT * FROM users
                         WHERE name LIKE ? OR phone LIKE ?
                         ORDER BY id DESC LIMIT 200');
    $like = '%' . $q . '%';
    $st->execute([$like, $like]);
} else {
    $st = $pdo->query('SELECT * FROM users ORDER BY id DESC LIMIT 200');
}
$students = $st->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:1100px">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="fw-bold mb-0" style="color:#0C1E7F">👥 Students</h3>
    <a href="<?= SITE_URL ?>/admin/dashboard.php" class="btn btn-outline-secondary btn-sm">
      ← Dashboard
    </a>
  </div>

  <!-- Search -->
  <form method="get" class="mb-3">
    <div class="input-group">
      <input type="text" name="q" class="form-control"
             placeholder="Search by name or phone..."
             value="<?= e($q) ?>">
      <button class="btn btn-primary">Search</button>
      <?php if ($q !== ''): ?>
        <a href="?" class="btn btn-outline-secondary">Clear</a>
      <?php endif; ?>
    </div>
  </form>

  <p class="text-muted small">
    Showing <b><?= count($students) ?></b> student(s)
    <?= $q !== '' ? 'matching "' . e($q) . '"' : '' ?>
  </p>

  <?php if (empty($students)): ?>
    <div class="alert alert-secondary">No students found.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-hover align-middle bg-white shadow-sm"
             style="border-radius:12px;overflow:hidden">
        <thead style="background:#0C1E7F;color:#fff">
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Grade</th>
            <th>Subscription</th>
            <th>Joined</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($students as $s):
            $subbed = is_subscribed($s);
          ?>
            <tr>
              <td>#<?= (int)$s['id'] ?></td>
              <td class="fw-bold"><?= e($s['name']) ?></td>
              <td><?= e($s['phone']) ?></td>
              <td>
                <?php if (($s['grade'] ?? '') === 'ALL'): ?>
                  <span class="badge bg-warning text-dark">🌟 All Grades</span>
                <?php elseif (!empty($s['grade'])): ?>
                  <span class="badge bg-primary"><?= e($s['grade']) ?></span>
                <?php else: ?>
                  <span class="text-muted small">—</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($subbed): ?>
                  <span class="badge bg-success">✅ Active</span>
                  <div class="small text-muted">
                    <?= sub_days_left($s) ?> day(s) left ·
                    <?= e(fmt_date($s['subscription_end'])) ?>
                  </div>
                  <div class="small" style="color:#0C1E7F">
                    <?= e(PLANS[$s['subscription_plan']]['label'] ?? $s['subscription_plan']) ?>
                  </div>
                <?php else: ?>
                  <span class="badge bg-secondary">❌ None</span>
                <?php endif; ?>
              </td>
              <td class="small text-muted">
                <?= e(fmt_date($s['created_at'] ?? null)) ?>
              </td>
              <td>
                <?php if ($subbed): ?>
                  <form method="post" class="d-inline"
                        onsubmit="return confirm('Cancel this student\'s subscription?');">
                    <input type="hidden" name="user_id" value="<?= (int)$s['id'] ?>">
                    <input type="hidden" name="action" value="cancel_sub">
                    <button class="btn btn-sm btn-warning">🚫 Cancel Sub</button>
                  </form>
                <?php endif; ?>

                <form method="post" class="d-inline"
                      onsubmit="return confirm('PERMANENTLY delete this student and all their payments?');">
                  <input type="hidden" name="user_id" value="<?= (int)$s['id'] ?>">
                  <input type="hidden" name="action" value="delete">
                  <button class="btn btn-sm btn-outline-danger">🗑️ Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>