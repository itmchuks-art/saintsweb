<?php
require_once __DIR__ . '/../includes/db.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $n = trim($_POST['name'] ?? '');
        $c = trim($_POST['class_level'] ?? '');

        if ($n === '' || $c === '') {
            flash('Enter a subject name and choose a grade.', 'danger');
        } elseif (!in_array($c, CLASS_LEVELS, true)) {
            flash('Invalid grade selected.', 'danger');
        } else {
            // Check if it already exists
            $check = $pdo->prepare('SELECT id FROM subjects WHERE LOWER(TRIM(name))=LOWER(TRIM(?)) AND class_level=? LIMIT 1');
            $check->execute([$n, $c]);
            $existing = $check->fetch();

            if ($existing) {
                flash('⚠️ "' . $n . '" already exists for ' . $c . '.', 'warning');
            } else {
                try {
                    $pdo->prepare('INSERT INTO subjects (name, class_level) VALUES (?,?)')
                        ->execute([$n, $c]);
                    flash('✅ Subject "' . $n . '" added to ' . $c . '.');
                } catch (PDOException $e) {
                    if ($e->getCode() == 23000) {
                        flash('⚠️ "' . $n . '" already exists for ' . $c . '.', 'warning');
                    } else {
                        flash('Error: ' . $e->getMessage(), 'danger');
                    }
                }
            }
        }
    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $pdo->prepare('DELETE FROM subjects WHERE id=?')->execute([$id]);
        $pdo->prepare('DELETE FROM questions WHERE subject_id=?')->execute([$id]);
        flash('Subject and its questions deleted.');
    }
    redirect('subjects.php');
}

$rows = $pdo->query('SELECT s.*, (SELECT COUNT(*) FROM questions q WHERE q.subject_id=s.id) AS qcount
                     FROM subjects s ORDER BY s.class_level, s.name')->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<style>
  .admin-banner {
    background: linear-gradient(135deg, #CE1126 0%, #0C1E7F 50%, #3A7728 100%);
    color: #fff;
    border-radius: 18px;
    padding: 22px;
    margin-bottom: 18px;
    position: relative;
    overflow: hidden;
    box-shadow: 0 10px 28px rgba(12,30,127,0.25);
  }
  .admin-banner::after {
    content: "";
    position: absolute;
    right: -50px; top: -50px;
    width: 160px; height: 160px;
    background: rgba(255,255,255,0.1);
    border-radius: 50%;
  }
  .admin-banner h3 { margin: 0; font-weight: 800; position: relative; z-index: 2; }
  .admin-banner p { margin: 4px 0 0; opacity: 0.9; position: relative; z-index: 2; font-size: 0.9rem; }

  .add-card {
    border: none;
    border-radius: 16px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.06);
    overflow: hidden;
  }
  .add-card .card-header {
    background: linear-gradient(135deg, #0C1E7F, #1e40af);
    color: #fff;
    border: none;
    padding: 14px 20px;
    font-weight: 700;
  }

  .subj-table {
    background: #fff;
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 6px 20px rgba(0,0,0,0.05);
  }
  .subj-table th {
    background: #0C1E7F;
    color: #fff;
    border: none;
    font-weight: 600;
    font-size: 0.85rem;
    padding: 12px;
  }
  .subj-table td {
    vertical-align: middle;
    border-color: #f1f5f9;
    padding: 12px;
  }
  .grade-chip {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 0.78rem;
    font-weight: 600;
    color: #fff;
  }
  .grade-nat3 { background: #CE1126; }
  .grade-nat6 { background: #0C1E7F; }
  .grade-nat8 { background: #3A7728; }
</style>

<div class="admin-banner">
  <h3>📚 Manage Subjects</h3>
  <p>Add or delete subjects for each NAT grade</p>
</div>

<div class="card add-card mb-4">
  <div class="card-header">➕ Add New Subject</div>
  <div class="card-body p-3">
    <form method="post" class="row g-2">
      <div class="col-12 col-md-6">
        <input name="name" class="form-control form-control-lg"
               placeholder="e.g. English, Maths, SES, Science" required>
      </div>
      <div class="col-12 col-md-4">
        <select name="class_level" class="form-select form-select-lg" required>
          <option value="">-- Grade --</option>
          <?php foreach (CLASS_LEVELS as $c): ?>
            <option><?= e($c) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-12 col-md-2">
        <button name="add" class="btn btn-primary btn-lg w-100">Add</button>
      </div>
    </form>
  </div>
</div>

<?php if (!$rows): ?>
  <div class="alert alert-info">No subjects yet. Add your first one above ☝️</div>
<?php else: ?>
  <div class="table-responsive subj-table">
    <table class="table mb-0">
      <thead>
        <tr>
          <th>#</th>
          <th>Subject</th>
          <th>Grade</th>
          <th>Questions</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $r):
        $gcls = 'grade-nat3';
        if ($r['class_level'] === 'NAT Grade 6') $gcls = 'grade-nat6';
        if ($r['class_level'] === 'NAT Grade 8') $gcls = 'grade-nat8';
      ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td><b><?= e($r['name']) ?></b></td>
          <td><span class="grade-chip <?= $gcls ?>"><?= e($r['class_level']) ?></span></td>
          <td><?= (int)$r['qcount'] ?></td>
          <td>
            <form method="post"
                  onsubmit="return confirm('Delete this subject AND all its questions?')">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button name="delete" class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <p class="text-muted small mt-2">Total: <?= count($rows) ?> subject(s)</p>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>