<?php
if (!function_exists('e')) {
    require_once __DIR__ . '/db.php';
}
?>
<footer class="text-center text-muted py-4 mt-5">
  <div class="container">
    <p class="mb-0 small">
      © <?= date('Y') ?> Test Me Mr 🇬🇲 — Made for Gambian schools.
    </p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>