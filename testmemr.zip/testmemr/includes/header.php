<?php
/* Make sure db.php is loaded */
if (!function_exists('e')) {
    require_once __DIR__ . '/db.php';
}

/* Detect admin vs student */
$__is_admin   = !empty($_SESSION['admin_id']);
$__is_student = !empty($_SESSION['user_id']);

/* Current file name */
$__current = basename($_SERVER['PHP_SELF'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Test Me Mr 🇬🇲</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
  :root {
    --gambia-red:   #CE1126;
    --gambia-blue:  #0C1E7F;
    --gambia-green: #3A7728;
  }

  body {
    background: #f5f7ff;
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  }

  .tmr-nav {
    background: #fff;
    box-shadow: 0 2px 12px rgba(12,30,127,.08);
    padding: 10px 0;
  }
  .tmr-brand {
    display: flex;
    align-items: center;
    gap: 12px;
    text-decoration: none;
    color: #0f172a;
    font-weight: 800;
    font-size: 1.1rem;
  }
  .tmr-flag {
    width: 44px;
    height: 32px;
    border-radius: 4px;
    overflow: hidden;
    border: 1px solid #e5e7eb;
    display: flex;
    flex-direction: column;
  }
  .tmr-flag div { width: 100%; }
  .tmr-flag .f1 { height: 8px;  background: var(--gambia-red); }
  .tmr-flag .f2 { height: 4px;  background: #fff; }
  .tmr-flag .f3 { height: 8px;  background: var(--gambia-blue); }
  .tmr-flag .f4 { height: 4px;  background: #fff; }
  .tmr-flag .f5 { height: 8px;  background: var(--gambia-green); }

  .tmr-nav .nav-link {
    color: #0f172a;
    font-weight: 600;
    padding: 6px 14px !important;
    border-radius: 10px;
    font-size: .92rem;
    transition: all .15s;
  }
  .tmr-nav .nav-link:hover {
    background: #eff6ff;
    color: var(--gambia-blue);
  }
  .tmr-nav .nav-link.active {
    background: linear-gradient(135deg, var(--gambia-blue), #1e40af);
    color: #fff;
  }
  .tmr-nav .nav-link.danger-link { color: var(--gambia-red); }
  .tmr-nav .nav-link.danger-link:hover { background: #fee2e2; }

  .tmr-username {
    font-weight: 700;
    color: var(--gambia-blue);
    font-size: .85rem;
  }

  .tmr-flash { margin-top: 14px; }
  .card { border-radius: 14px; }

  @media (max-width: 576px) {
    .tmr-brand { font-size: 1rem; }
    .tmr-nav .nav-link { padding: 6px 10px !important; font-size: .85rem; }
  }
</style>
</head>
<body>

<nav class="tmr-nav">
  <div class="container d-flex align-items-center justify-content-between flex-wrap gap-2">

    <a class="tmr-brand" href="<?= SITE_URL ?>/index.php">
      <div class="tmr-flag">
        <div class="f1"></div><div class="f2"></div><div class="f3"></div>
        <div class="f4"></div><div class="f5"></div>
      </div>
      <span>Test Me Mr 🇬🇲</span>
    </a>

    <ul class="nav flex-wrap align-items-center mb-0">

      <?php if ($__is_admin): ?>

        <!-- ADMIN NAV -->
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'dashboard.php' && strpos($_SERVER['PHP_SELF'], '/admin/') !== false ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/admin/dashboard.php">🛡️ Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'payments.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/admin/payments.php">💳 Payments</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'students.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/admin/students.php">👥 Students</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'subjects.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/admin/subjects.php">📚 Subjects</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'questions.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/admin/questions.php">❓ Questions</a>
        </li>
        <li class="nav-item">
          <span class="tmr-username ms-2">👤 <?= e($_SESSION['admin_name'] ?? 'Admin') ?></span>
        </li>
        <li class="nav-item">
          <a class="nav-link danger-link" href="<?= SITE_URL ?>/admin/logout.php">Logout</a>
        </li>

      <?php elseif ($__is_student): ?>

        <!-- STUDENT NAV -->
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'dashboard.php' && strpos($_SERVER['PHP_SELF'], '/student/') !== false ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/student/dashboard.php">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'subjects.php' || $__current === 'practice.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/student/subjects.php">Subjects</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'exam.php' || $__current === 'take_test.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/student/exam.php">📝 Write Test</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'subscription.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/student/subscription.php">Subscribe</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'profile.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/student/profile.php">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link danger-link" href="<?= SITE_URL ?>/student/logout.php">Logout</a>
        </li>

      <?php else: ?>

        <!-- GUEST NAV -->
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'login.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/login.php">Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $__current === 'register.php' ? 'active' : '' ?>"
             href="<?= SITE_URL ?>/register.php">Student Register</a>
        </li>

      <?php endif; ?>

    </ul>
  </div>
</nav>

<?php
$__flashes = function_exists('take_flashes') ? take_flashes() : [];
if ($__flashes):
?>
<div class="container tmr-flash">
  <?php foreach ($__flashes as $f):
    $t = $f['t'] ?? 'info';
    $bs = [
      'success' => 'success',
      'info'    => 'info',
      'warning' => 'warning',
      'danger'  => 'danger',
      'error'   => 'danger',
    ][$t] ?? 'info';
  ?>
    <div class="alert alert-<?= $bs ?> alert-dismissible fade show" role="alert">
      <?= $f['m'] ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>