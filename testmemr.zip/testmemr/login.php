<?php
require_once __DIR__ . '/includes/db.php';

/* Already logged in? Send forward */
if (!empty($_SESSION['user_id'])) {
    $st = $pdo->prepare('SELECT grade FROM users WHERE id = ? LIMIT 1');
    $st->execute([(int)$_SESSION['user_id']]);
    $u = $st->fetch();

    if ($u) {
        if (empty($u['grade'])) {
            redirect(SITE_URL . '/student/choose_grade.php');
        }
        redirect(SITE_URL . '/student/welcome.php');
    }
    unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['session_token']);
}

$mode  = $_GET['mode'] ?? 'student';
$error = '';
$name  = '';
$phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode  = $_POST['mode'] ?? 'student';
    $name  = trim($_POST['name']  ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if ($name === '' || $phone === '') {
        $error = 'Enter your name and phone number.';
    } else {
        if ($mode === 'admin') {
            $st = $pdo->prepare('SELECT * FROM admins WHERE name = ? AND phone = ? LIMIT 1');
            $st->execute([$name, $phone]);
            $admin = $st->fetch();

            if (!$admin) {
                $error = 'Invalid admin name or phone.';
            } else {
                $_SESSION['admin_id']   = (int)$admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                flash('👋 Welcome, ' . $admin['name']);
                redirect(SITE_URL . '/admin/dashboard.php');
            }
        } else {
            $st = $pdo->prepare('SELECT * FROM users WHERE name = ? AND phone = ? LIMIT 1');
            $st->execute([$name, $phone]);
            $user = $st->fetch();

            if (!$user) {
                $error = 'No student account found. Please register.';
            } else {
                $_SESSION['user_id']   = (int)$user['id'];
                $_SESSION['user_name'] = $user['name'];

                /* Reset welcome so it shows once after login */
                unset($_SESSION['seen_welcome']);

                generate_session_token($pdo, (int)$user['id']);

                flash('👋 Welcome back, ' . $user['name'] . '!');

                /* No grade yet? pick first. Otherwise → welcome */
                if (empty($user['grade'])) {
                    redirect(SITE_URL . '/student/choose_grade.php');
                }
                redirect(SITE_URL . '/student/welcome.php');
            }
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<div class="container py-5" style="max-width:480px">
  <div class="text-center mb-4">
    <h2 class="fw-bold" style="color:#0C1E7F">Test Me Mr 🇬🇲</h2>
    <p class="text-muted">Log in to continue</p>
  </div>

  <ul class="nav nav-pills nav-justified mb-3">
    <li class="nav-item">
      <a class="nav-link <?= $mode !== 'admin' ? 'active' : '' ?>"
         href="?mode=student"
         style="<?= $mode !== 'admin' ? 'background:#0C1E7F;color:#fff' : 'color:#0C1E7F;border:1px solid #0C1E7F' ?>">
        👤 Student
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?= $mode === 'admin' ? 'active' : '' ?>"
         href="?mode=admin"
         style="<?= $mode === 'admin' ? 'background:#CE1126;color:#fff' : 'color:#CE1126;border:1px solid #CE1126' ?>">
        🛡️ Admin
      </a>
    </li>
  </ul>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
  <?php endif; ?>

  <form method="post" class="card p-4 shadow-sm" style="border-radius:18px">
    <input type="hidden" name="mode" value="<?= e($mode) ?>">

    <div class="mb-3">
      <label class="form-label fw-bold">Full Name</label>
      <input type="text" name="name" class="form-control form-control-lg"
             value="<?= e($name) ?>" placeholder="e.g. Moses Ibuchim Chuku"
             required autofocus>
    </div>

    <div class="mb-3">
      <label class="form-label fw-bold">Phone Number</label>
      <input type="text" name="phone" class="form-control form-control-lg"
             value="<?= e($phone) ?>" placeholder="e.g. 7705902" required>
      <div class="form-text">
        ⚠️ One account can only be open on <b>one device</b> at a time.
      </div>
    </div>

    <button type="submit"
            class="btn w-100 py-3 fw-bold"
            style="border-radius:12px;border:none;color:#fff;background:<?= $mode === 'admin'
                ? 'linear-gradient(135deg,#CE1126,#a30d1e)'
                : 'linear-gradient(135deg,#0C1E7F,#1e40af)' ?>">
      <?= $mode === 'admin' ? '🛡️ Admin Login' : '👤 Student Login' ?>
    </button>

    <?php if ($mode !== 'admin'): ?>
      <p class="text-center text-muted mt-3 mb-0 small">
        New student?
        <a href="<?= SITE_URL ?>/register.php" class="fw-bold">Create an account</a>
      </p>
    <?php else: ?>
      <p class="text-center text-muted mt-3 mb-0 small">
        <a href="<?= SITE_URL ?>/admin/register.php">Create admin</a>
      </p>
    <?php endif; ?>
  </form>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>