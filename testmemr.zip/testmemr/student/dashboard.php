<?php
require_once __DIR__ . '/../includes/db.php';
$user = require_student($pdo);

/* Refresh */
$st = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$st->execute([(int)$user['id']]);
$user = $st->fetch();

/* Parse active grades */
$active_grades = [];
if (!empty($user['subscribed_grades'])) {
    $active_grades = array_map('trim', explode(',', $user['subscribed_grades']));
    $active_grades = array_values(array_filter($active_grades, fn($g) => $g !== ''));
}
if (($user['grade'] ?? '') === 'ALL' || strpos($user['subscription_plan'] ?? '', 'all_') === 0) {
    $active_grades = CLASS_LEVELS;
}

/* Grades still available to add */
$can_add = array_values(array_diff(CLASS_LEVELS, $active_grades));

$active = is_subscribed($user);
$days   = sub_days_left($user);

/* Has everything? */
$has_all = (count($active_grades) === count(CLASS_LEVELS));

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:1000px">

  <h2 class="fw-bold mb-1" style="color:#0C1E7F">
    👋 Welcome, <?= e($user['name']) ?>
  </h2>
  <p class="text-muted">Your learning dashboard</p>

  <!-- Subscription status -->
  <div class="card p-4 mb-4 border-0 shadow-sm"
       style="border-radius:18px;background:<?= $active ? 'linear-gradient(135deg,#3A7728,#16a34a)' : 'linear-gradient(135deg,#CE1126,#dc2626)' ?>;color:#fff">

    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
      <div>
        <div class="small opacity-75">Subscription Status</div>
        <div class="fs-3 fw-bold">
          <?= $active ? '✅ Active' : '❌ Not Active' ?>
        </div>
      </div>

      <?php if ($active): ?>
        <div class="text-end">
          <div class="small opacity-75">Expires on</div>
          <div class="fw-bold"><?= e(fmt_date($user['subscription_end'])) ?></div>
          <div class="small"><?= $days ?> day(s) remaining</div>
        </div>
      <?php endif; ?>
    </div>

    <?php if ($active && !empty($user['subscription_plan']) && isset(PLANS[$user['subscription_plan']])): ?>
      <div class="mt-3 pt-3" style="border-top:1px solid rgba(255,255,255,.25)">
        <div class="small opacity-75">Current Plan</div>
        <div class="fw-bold"><?= e(PLANS[$user['subscription_plan']]['label']) ?></div>
      </div>
    <?php endif; ?>
  </div>

  <!-- ============================================================
       YOUR GRADES
       ============================================================ -->
  <div class="card p-4 mb-4 shadow-sm" style="border-radius:16px">
    <h5 class="fw-bold mb-3" style="color:#0C1E7F">
      🎓 Your Subscribed Grades
      <span class="badge bg-primary"><?= count($active_grades) ?></span>
    </h5>

    <?php if (empty($active_grades)): ?>
      <div class="alert alert-warning mb-0">
        ⚠️ You have no active grades yet.
        <a href="<?= SITE_URL ?>/student/subscription.php" class="fw-bold">
          Subscribe now →
        </a>
      </div>
    <?php else: ?>
      <div class="row g-3">
        <?php foreach ($active_grades as $g):
          $label = ($g === 'ALL') ? '🌟 All Grades' : $g;
        ?>
          <div class="col-12 col-md-6">
            <div class="d-flex align-items-center gap-3 p-3 rounded-3"
                 style="background:linear-gradient(135deg,#eff6ff,#f0fdf4);border:2px solid #0C1E7F">
              <div class="fs-2"><?= $g === 'ALL' ? '🌟' : '🎓' ?></div>
              <div class="flex-grow-1">
                <div class="fw-bold" style="color:#0C1E7F"><?= e($label) ?></div>
                <div class="small text-muted">
                  <?= $active ? 'Active until ' . e(fmt_date($user['subscription_end'])) : 'Not active' ?>
                </div>
              </div>
              <?php if ($active): ?>
                <a href="<?= SITE_URL ?>/student/subjects.php?grade=<?= urlencode($g) ?>"
                   class="btn btn-sm btn-primary">Open →</a>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <!-- ============================================================
         NOTICE: get more grades
         ============================================================ -->
    <?php if (!$has_all): ?>
      <div class="mt-4 p-3 rounded-3 d-flex align-items-center gap-3 flex-wrap"
           style="background:linear-gradient(135deg,#fef3c7,#fde68a);border:2px dashed #d97706">
        <div class="fs-2">🔓</div>
        <div class="flex-grow-1">
          <div class="fw-bold" style="color:#78350f">
            You can get more grades here!
          </div>
          <div class="small" style="color:#78350f">
            <?= count($can_add) ?> grade(s) still available to unlock:
            <b><?= implode(' · ', array_map('e', $can_add)) ?></b>
          </div>
        </div>
        <a href="<?= SITE_URL ?>/student/subscription.php"
           class="btn fw-bold"
           style="background:linear-gradient(135deg,#d97706,#b45309);color:#fff;border:none;border-radius:10px">
          ➕ Subscribe for More Grades
        </a>
      </div>
    <?php else: ?>
      <div class="mt-4 p-3 rounded-3 d-flex align-items-center gap-3"
           style="background:linear-gradient(135deg,#dcfce7,#bbf7d0);border:2px solid #16a34a">
        <div class="fs-2">🌟</div>
        <div class="flex-grow-1">
          <div class="fw-bold" style="color:#14532d">
            You have every grade unlocked!
          </div>
          <div class="small" style="color:#14532d">
            You're subscribed to all 4 grades — nice work.
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <!-- Quick actions -->
  <div class="row g-3">
    <div class="col-md-3">
      <a href="<?= SITE_URL ?>/student/subjects.php"
         class="card p-4 text-decoration-none shadow-sm h-100 border-0"
         style="border-radius:16px;border-left:5px solid #0C1E7F !important">
        <div class="fs-1">📚</div>
        <div class="fw-bold mt-2" style="color:#0C1E7F">Subjects</div>
        <div class="small text-muted">Browse questions</div>
      </a>
    </div>

    <div class="col-md-3">
      <a href="<?= SITE_URL ?>/student/exam.php"
         class="card p-4 text-decoration-none shadow-sm h-100 border-0"
         style="border-radius:16px;border-left:5px solid #d97706 !important">
        <div class="fs-1">📝</div>
        <div class="fw-bold mt-2" style="color:#78350f">Write Test</div>
        <div class="small text-muted">Practice exam</div>
      </a>
    </div>

    <div class="col-md-3">
      <a href="<?= SITE_URL ?>/student/subscription.php"
         class="card p-4 text-decoration-none shadow-sm h-100 border-0"
         style="border-radius:16px;border-left:5px solid #3A7728 !important">
        <div class="fs-1">💳</div>
        <div class="fw-bold mt-2" style="color:#3A7728">Subscription</div>
        <div class="small text-muted">View plans</div>
      </a>
    </div>

    <div class="col-md-3">
      <a href="<?= SITE_URL ?>/student/profile.php"
         class="card p-4 text-decoration-none shadow-sm h-100 border-0"
         style="border-radius:16px;border-left:5px solid #CE1126 !important">
        <div class="fs-1">👤</div>
        <div class="fw-bold mt-2" style="color:#CE1126">Profile</div>
        <div class="small text-muted">Update details</div>
      </a>
    </div>
  </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>