<?php
require_once __DIR__ . '/../includes/db.php';
$user = require_student($pdo);

$st = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$st->execute([(int)$user['id']]);
$user = $st->fetch();

if (!is_subscribed($user)) {
    flash('⚠️ Subscribe first to write a test.', 'warning');
    redirect(SITE_URL . '/student/subscription.php');
}

/* Active grades */
$active_grades = [];
if (!empty($user['subscribed_grades'])) {
    $active_grades = array_map('trim', explode(',', $user['subscribed_grades']));
    $active_grades = array_values(array_filter($active_grades));
}
if (($user['grade'] ?? '') === 'ALL' || strpos($user['subscription_plan'] ?? '', 'all_') === 0) {
    $active_grades = CLASS_LEVELS;
}
if (empty($active_grades) && !empty($user['grade']) && $user['grade'] !== 'ALL') {
    $active_grades = [$user['grade']];
}

/* Auto-retake */
if (!empty($_GET['retake']) && !empty($active_grades)) {
    $retake_id    = (int)$_GET['retake'];
    $placeholders = implode(',', array_fill(0, count($active_grades), '?'));

    try {
        $chk = $pdo->prepare("
            SELECT id FROM subjects
            WHERE id = ?
              AND (class_level IN ($placeholders) OR grade IN ($placeholders))
            LIMIT 1
        ");
        $chk->execute(array_merge([$retake_id], $active_grades, $active_grades));

        if ($chk->fetch()) {
            unset(
                $_SESSION['exam_questions'],
                $_SESSION['exam_subject'],
                $_SESSION['exam_started'],
                $_SESSION['exam_subject_row'],
                $_SESSION['exam_ends_at']
            );
            $_SESSION['exam_subject_id'] = $retake_id;
            $_SESSION['exam_count']      = 10;
            $_SESSION['exam_minutes']    = 0;   /* 0 = no timer for retake */
            redirect(SITE_URL . '/student/take_test.php?start=1');
        }
    } catch (Exception $e) { }
}

/* Load subjects */
$subjects = [];
try {
    if (!empty($active_grades)) {
        $in = implode(',', array_fill(0, count($active_grades), '?'));
        $st = $pdo->prepare("
            SELECT * FROM subjects
            WHERE class_level IN ($in) OR grade IN ($in)
            ORDER BY class_level, name
        ");
        $st->execute(array_merge($active_grades, $active_grades));
        $subjects = $st->fetchAll();
    }
    if (empty($subjects)) {
        $subjects = $pdo->query('SELECT * FROM subjects ORDER BY name')->fetchAll();
    }
} catch (Exception $e) { $subjects = []; }

foreach ($subjects as &$s) {
    $s['grade'] = $s['class_level'] ?? ($s['grade'] ?? '');
}
unset($s);

/* START EXAM */
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject_id = (int)($_POST['subject_id'] ?? 0);
    $count      = max(5, min(50, (int)($_POST['count'] ?? 10)));
    $minutes    = max(0, min(25, (int)($_POST['minutes'] ?? 0)));  /* 0 = no timer */

    if ($subject_id <= 0) {
        $error = 'Choose a subject.';
    } else {
        unset(
            $_SESSION['exam_questions'],
            $_SESSION['exam_subject'],
            $_SESSION['exam_started'],
            $_SESSION['exam_subject_row'],
            $_SESSION['exam_ends_at']
        );
        $_SESSION['exam_subject_id'] = $subject_id;
        $_SESSION['exam_count']      = $count;
        $_SESSION['exam_minutes']    = $minutes;
        redirect(SITE_URL . '/student/take_test.php?start=1');
    }
}

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:900px">

  <div class="mb-4">
    <h2 class="fw-bold mb-1" style="color:#0C1E7F">📝 Write a Test</h2>
    <p class="text-muted">Choose a subject, number of questions, and how long you want.</p>
  </div>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
  <?php endif; ?>

  <?php if (empty($subjects)): ?>
    <div class="alert alert-warning">⚠️ No subjects available yet.</div>
  <?php else: ?>
    <form method="post" class="card p-4 shadow-sm mb-4" style="border-radius:18px">

      <!-- GRADE -->
      <?php if (count($active_grades) > 1): ?>
        <div class="mb-3">
          <label class="form-label fw-bold">Grade</label>
          <select id="gradePicker" class="form-select form-select-lg">
            <?php foreach ($active_grades as $i => $g): ?>
              <option value="<?= e($g) ?>" <?= $i === 0 ? 'selected' : '' ?>>
                <?= e($g) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      <?php else: ?>
        <div class="mb-3">
          <label class="form-label fw-bold">Grade</label>
          <div class="form-control form-control-lg bg-light" style="cursor:default">
            🎓 <b><?= e($active_grades[0] ?? 'No grade') ?></b>
          </div>
        </div>
      <?php endif; ?>

      <!-- SUBJECT -->
      <div class="mb-3">
        <label class="form-label fw-bold">Subject</label>
        <select name="subject_id" id="subjectPicker" class="form-select form-select-lg" required>
          <option value="" data-grade="">-- Choose subject --</option>
          <?php foreach ($subjects as $s): ?>
            <option value="<?= (int)$s['id'] ?>" data-grade="<?= e($s['grade'] ?? '') ?>">
              <?= e($s['name']) ?><?= !empty($s['grade']) ? ' (' . e($s['grade']) . ')' : '' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- NUMBER OF QUESTIONS -->
      <div class="mb-3">
        <label class="form-label fw-bold">📊 Number of questions</label>
        <select name="count" class="form-select form-select-lg">
          <option value="5">5 questions</option>
          <option value="10" selected>10 questions</option>
          <option value="15">15 questions</option>
          <option value="20">20 questions</option>
          <option value="25">25 questions</option>
          <option value="30">30 questions</option>
          <option value="35">35 questions</option>
          <option value="40">40 questions</option>
          <option value="45">45 questions</option>
          <option value="50">50 questions</option>
        </select>
      </div>

      <!-- TIMER (optional) -->
      <div class="mb-3">
        <label class="form-label fw-bold">⏱️ Time limit</label>
        <select name="minutes" class="form-select form-select-lg">
          <option value="0" selected>🚫 No timer — take your time</option>
          <option value="5">5 minutes</option>
          <option value="10">10 minutes</option>
          <option value="15">15 minutes</option>
          <option value="20">20 minutes</option>
          <option value="25">25 minutes</option>
        </select>
        <div class="form-text">
          If you set a timer, your test will be submitted automatically when time runs out.
        </div>
      </div>

      <button class="btn btn-success w-100 py-3 fw-bold"
              style="border-radius:12px;background:linear-gradient(135deg,#3A7728,#16a34a);border:none">
        🚀 Start Test
      </button>
    </form>

    <script>
    (function () {
      var g = document.getElementById('gradePicker');
      var s = document.getElementById('subjectPicker');
      if (!s) return;

      function filter() {
        var grade = g ? g.value : <?= json_encode($active_grades[0] ?? '') ?>;
        s.querySelectorAll('option').forEach(function (o) {
          if (!o.value) return;
          var og = o.getAttribute('data-grade') || '';
          var show = (grade === '' || og === grade);
          o.hidden = !show;
          o.disabled = !show;
        });
        if (s.selectedOptions[0] && s.selectedOptions[0].disabled) {
          s.value = '';
          var first = s.querySelector('option:not([disabled]):not([value=""])');
          if (first) s.value = first.value;
        }
      }
      if (g) g.addEventListener('change', filter);
      filter();
    })();
    </script>
  <?php endif; ?>

  <!-- Recent tests -->
  <?php
  $past = [];
  try {
      $ph = $pdo->prepare('SELECT a.*, s.name AS subject_name
                           FROM attempts a
                           LEFT JOIN subjects s ON s.id = a.subject_id
                           WHERE a.user_id = ?
                           ORDER BY a.id DESC LIMIT 10');
      $ph->execute([(int)$user['id']]);
      $past = $ph->fetchAll();
  } catch (Exception $e) { }

  function list_grade(int $p): array {
      if ($p >= 90) return ['A+', 'success'];
      if ($p >= 80) return ['A',  'success'];
      if ($p >= 70) return ['B',  'success'];
      if ($p >= 60) return ['C',  'warning text-dark'];
      if ($p >= 50) return ['D',  'warning text-dark'];
      if ($p >= 40) return ['E',  'danger'];
      return              ['F',  'danger'];
  }
  ?>

  <?php if ($past): ?>
    <h5 class="fw-bold mt-5 mb-3" style="color:#0C1E7F">📜 Recent Tests</h5>
    <?php foreach ($past as $a):
      [$letter, $badge] = list_grade((int)$a['percent']);
    ?>
      <div class="card p-3 mb-2 border-0 shadow-sm">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <div class="fw-bold"><?= e($a['subject_name'] ?? '—') ?></div>
            <div class="small text-muted">
              <?= e($a['grade']) ?> · <?= e(fmt_date($a['finished_at'] ?? $a['started_at'])) ?>
            </div>
          </div>
          <div class="text-end">
            <div class="fw-bold mb-1" style="color:#0C1E7F">
              <?= (int)$a['score'] ?>/<?= (int)$a['total'] ?>
            </div>
            <span class="badge bg-<?= $badge ?>">
              <?= e($letter) ?> · <?= (int)$a['percent'] ?>%
            </span>
          </div>
        </div>
        <div class="mt-2 text-end">
          <a href="?retake=<?= (int)$a['subject_id'] ?>" class="btn btn-sm btn-outline-success">
            🔁 Retake
          </a>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>