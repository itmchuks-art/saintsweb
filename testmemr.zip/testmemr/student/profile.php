<?php
require_once __DIR__ . '/../includes/db.php';
$user = require_student($pdo);

/* Refresh user */
$st = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$st->execute([(int)$user['id']]);
$user = $st->fetch();

$error   = '';
$success = '';

/* ---------- Handle POST ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name  = trim($_POST['name']  ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if ($name === '' || strlen($name) < 3) {
        $error = 'Enter a valid name (at least 3 characters).';
    } elseif (!preg_match('/^[0-9]{7,10}$/', $phone)) {
        $error = 'Enter a valid phone number (7–10 digits, no +220).';
    } else {
        /* Block duplicate name + phone (except current user) */
        $chk = $pdo->prepare('SELECT id FROM users WHERE name = ? AND phone = ? AND id != ? LIMIT 1');
        $chk->execute([$name, $phone, (int)$user['id']]);

        if ($chk->fetch()) {
            $error = 'Another student is already using that name + phone.';
        } else {
            try {
                $pdo->prepare('UPDATE users SET name = ?, phone = ? WHERE id = ?')
                    ->execute([$name, $phone, (int)$user['id']]);

                $_SESSION['user_name'] = $name;
                flash('✅ Profile updated.');
                redirect(SITE_URL . '/student/profile.php');
            } catch (Exception $ex) {
                $error = 'Database error: ' . $ex->getMessage();
            }
        }
    }
}

/* Refresh after update */
$st = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$st->execute([(int)$user['id']]);
$user = $st->fetch();

/* ---------- Data for display ---------- */
$active_grades = [];
if (!empty($user['subscribed_grades'])) {
    $active_grades = array_map('trim', explode(',', $user['subscribed_grades']));
    $active_grades = array_values(array_filter($active_grades));
}
if (($user['grade'] ?? '') === 'ALL' || strpos($user['subscription_plan'] ?? '', 'all_') === 0) {
    $active_grades = CLASS_LEVELS;
}

$active = is_subscribed($user);

/* Recent tests */
$recent = [];
try {
    $ph = $pdo->prepare('SELECT a.*, s.name AS subject_name
                         FROM attempts a
                         LEFT JOIN subjects s ON s.id = a.subject_id
                         WHERE a.user_id = ?
                         ORDER BY a.id DESC LIMIT 5');
    $ph->execute([(int)$user['id']]);
    $recent = $ph->fetchAll();
} catch (Exception $e) { }

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:700px">

  <div class="text-center mb-4">
    <h2 class="fw-bold" style="color:#0C1E7F">👤 My Profile</h2>
    <p class="text-muted">Manage your account details</p>
  </div>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
  <?php endif; ?>

  <!-- ---------- Account card ---------- -->
  <div class="card p-4 mb-4 shadow-sm border-0"
       style="border-radius:18px;background:<?= $active ? 'linear-gradient(135deg,#3A7728,#16a34a)' : 'linear-gradient(135deg,#CE1126,#dc2626)' ?>;color:#fff">
    <div class="d-flex align-items-center gap-3">
      <div class="fs-1">👤</div>
      <div class="flex-grow-1">
        <div class="fs-4 fw-bold"><?= e($user['name']) ?></div>
        <div class="small opacity-75"><?= e($user['phone']) ?></div>
      </div>
      <div class="text-end">
        <div class="small opacity-75">Subscription</div>
        <div class="fw-bold"><?= $active ? '✅ Active' : '❌ Not Active' ?></div>
      </div>
    </div>

    <?php if ($active): ?>
      <div class="mt-3 pt-3" style="border-top:1px solid rgba(255,255,255,.25)">
        <div class="small">
          <b>Plan:</b>
          <?= e(PLANS[$user['subscription_plan']]['label'] ?? $user['subscription_plan']) ?>
        </div>
        <div class="small">
          <b>Expires:</b> <?= e(fmt_date($user['subscription_end'])) ?>
          · <?= sub_days_left($user) ?> day(s) left
        </div>
      </div>
    <?php endif; ?>
  </div>

  <!-- ---------- Subscribed grades ---------- -->
  <div class="card p-4 mb-4 shadow-sm" style="border-radius:16px">
    <h5 class="fw-bold mb-3" style="color:#0C1E7F">
      🎓 My Grades
      <span class="badge bg-primary"><?= count($active_grades) ?></span>
    </h5>

    <?php if (empty($active_grades)): ?>
      <div class="alert alert-warning mb-0">
        You have no grades yet.
        <a href="<?= SITE_URL ?>/student/subscription.php" class="fw-bold">Subscribe →</a>
      </div>
    <?php else: ?>
      <div class="d-flex flex-wrap gap-2">
        <?php foreach ($active_grades as $g): ?>
          <span class="badge bg-primary px-3 py-2" style="font-size:.85rem">
            <?= e($g) ?>
          </span>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- ---------- Edit form ---------- -->
  <div class="card p-4 mb-4 shadow-sm" style="border-radius:16px">
    <h5 class="fw-bold mb-3" style="color:#0C1E7F">✏️ Edit Details</h5>

    <form method="post">
      <div class="mb-3">
        <label class="form-label fw-bold">Full Name</label>
        <input name="name" class="form-control form-control-lg"
               value="<?= e($user['name']) ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-bold">Phone Number</label>
        <input name="phone" class="form-control form-control-lg"
               value="<?= e($user['phone']) ?>" required>
        <div class="form-text">7–10 digits, without +220.</div>
      </div>

      <button class="btn btn-primary w-100 py-3 fw-bold"
              style="border-radius:12px;background:linear-gradient(135deg,#0C1E7F,#1e40af);border:none">
        💾 Save Changes
      </button>
    </form>
  </div>

  <!-- ---------- Recent tests ---------- -->
  <?php if (!empty($recent)): ?>
    <div class="card p-4 mb-4 shadow-sm" style="border-radius:16px">
      <h5 class="fw-bold mb-3" style="color:#0C1E7F">📜 Recent Tests</h5>

      <?php foreach ($recent as $a):
        $badge = $a['percent'] >= 70 ? 'success' : ($a['percent'] >= 50 ? 'warning text-dark' : 'danger');
      ?>
        <div class="d-flex justify-content-between align-items-center border-bottom py-2">
          <div>
            <div class="fw-bold small"><?= e($a['subject_name'] ?? '—') ?></div>
            <div class="text-muted" style="font-size:.75rem">
              <?= e(fmt_date($a['finished_at'] ?? $a['started_at'])) ?>
            </div>
          </div>
          <span class="badge bg-<?= $badge ?>">
            <?= (int)$a['score'] ?>/<?= (int)$a['total'] ?> · <?= (int)$a['percent'] ?>%
          </span>
        </div>
      <?php endforeach; ?>

      <div class="text-center mt-3">
        <a href="<?= SITE_URL ?>/student/exam.php" class="btn btn-sm btn-outline-primary">
          Take a Test →
        </a>
      </div>
    </div>
  <?php endif; ?>

  <!-- ---------- Account meta ---------- -->
  <div class="card p-4 shadow-sm" style="border-radius:16px">
    <h5 class="fw-bold mb-3" style="color:#0C1E7F">ℹ️ Account Info</h5>

    <div class="small">
      <div class="d-flex justify-content-between py-1">
        <span class="text-muted">Account ID</span>
        <span class="fw-bold">#<?= (int)$user['id'] ?></span>
      </div>
      <div class="d-flex justify-content-between py-1">
        <span class="text-muted">Joined</span>
        <span class="fw-bold"><?= e(fmt_date($user['created_at'] ?? null)) ?></span>
      </div>
      <div class="d-flex justify-content-between py-1">
        <span class="text-muted">Last Test</span>
        <span class="fw-bold">
          <?= !empty($recent)
              ? e(fmt_date($recent[0]['finished_at'] ?? $recent[0]['started_at']))
              : 'No tests yet' ?>
        </span>
      </div>
    </div>
  </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>