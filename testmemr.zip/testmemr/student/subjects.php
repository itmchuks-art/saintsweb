<?php
require_once __DIR__ . '/../includes/db.php';
$user = require_student($pdo);

/* Refresh */
$st = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$st->execute([(int)$user['id']]);
$user = $st->fetch();

if (empty($user['grade']) && empty($user['subscribed_grades'])) {
    redirect(SITE_URL . '/student/choose_grade.php');
}

/* Which grades? */
$allowed_grades = [];
if (!empty($user['subscribed_grades'])) {
    $allowed_grades = array_map('trim', explode(',', $user['subscribed_grades']));
    $allowed_grades = array_values(array_filter($allowed_grades));
}
if (($user['grade'] ?? '') === 'ALL' || strpos($user['subscription_plan'] ?? '', 'all_') === 0) {
    $allowed_grades = CLASS_LEVELS;
}
if (empty($allowed_grades) && !empty($user['grade']) && $user['grade'] !== 'ALL') {
    $allowed_grades = [$user['grade']];
}

$active = is_subscribed($user);

$view = trim($_GET['grade'] ?? ($allowed_grades[0] ?? ''));
if (!in_array($view, $allowed_grades, true)) {
    $view = $allowed_grades[0] ?? null;
}

/* Load subjects */
$subjects = [];
if ($view) {
    try {
        $st = $pdo->prepare('
            SELECT * FROM subjects
            WHERE class_level = ? OR grade = ?
            ORDER BY name ASC
        ');
        $st->execute([$view, $view]);
        $subjects = $st->fetchAll();
    } catch (Exception $e) { $subjects = []; }
}

$can_add = array_values(array_diff(CLASS_LEVELS, $allowed_grades));

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:900px">

  <div class="text-center mb-4">
    <h2 class="fw-bold" style="color:#0C1E7F">📚 Subjects</h2>
    <p class="text-muted">Browse the subjects available in your grade.</p>
  </div>

  <?php if (!$active): ?>
    <div class="alert alert-warning">
      ⚠️ Your subscription is not active.
      <a href="<?= SITE_URL ?>/student/subscription.php" class="fw-bold">Subscribe →</a>
    </div>
  <?php endif; ?>

  <?php if (empty($allowed_grades)): ?>
    <div class="alert alert-info">
      No grades unlocked yet.
      <a href="<?= SITE_URL ?>/student/subscription.php" class="fw-bold">Subscribe →</a>
    </div>
  <?php else: ?>

    <!-- Grade tabs -->
    <ul class="nav nav-pills mb-3 flex-wrap">
      <?php foreach ($allowed_grades as $g): ?>
        <li class="nav-item me-2 mb-2">
          <a class="nav-link <?= $g === $view ? 'active' : '' ?>"
             href="?grade=<?= urlencode($g) ?>"
             style="<?= $g === $view
                ? 'background:#0C1E7F;color:#fff'
                : 'color:#0C1E7F;border:1px solid #0C1E7F' ?>">
            <?= e($g) ?>
          </a>
        </li>
      <?php endforeach; ?>
    </ul>

    <!-- More grades notice -->
    <?php if (!empty($can_add)): ?>
      <div class="p-3 rounded-3 mb-3 d-flex align-items-center gap-3 flex-wrap"
           style="background:linear-gradient(135deg,#fef3c7,#fde68a);border:2px dashed #d97706">
        <div class="fs-3">🔓</div>
        <div class="flex-grow-1">
          <div class="fw-bold" style="color:#78350f">
            You can get more grades here!
          </div>
          <div class="small" style="color:#78350f">
            Available: <b><?= implode(' · ', array_map('e', $can_add)) ?></b>
          </div>
        </div>
        <a href="<?= SITE_URL ?>/student/subscription.php"
           class="btn fw-bold"
           style="background:linear-gradient(135deg,#d97706,#b45309);color:#fff;border:none;border-radius:10px">
          ➕ Subscribe for More Grades
        </a>
      </div>
    <?php endif; ?>

    <!-- Big "Write Test" call to action -->
    <div class="card p-3 mb-4 border-0 shadow-sm"
         style="border-radius:14px;background:linear-gradient(135deg,#0C1E7F,#1e40af);color:#fff">
      <div class="d-flex align-items-center gap-3 flex-wrap">
        <div class="fs-1">📝</div>
        <div class="flex-grow-1">
          <div class="fw-bold">Ready to test yourself?</div>
          <div class="small opacity-75">
            Click <b>Write Test</b> to answer questions and get your score.
          </div>
        </div>
        <a href="<?= SITE_URL ?>/student/exam.php"
           class="btn fw-bold"
           style="background:#3A7728;color:#fff;border:none;border-radius:10px">
          📝 Write Test →
        </a>
      </div>
    </div>

    <!-- Subject list (browse only, no links) -->
    <?php if (empty($subjects)): ?>
      <div class="alert alert-secondary">
        📭 No subjects added for <b><?= e($view) ?></b> yet.
      </div>
    <?php else: ?>
      <div class="row g-3">
        <?php foreach ($subjects as $s): ?>
          <div class="col-6 col-md-4">
            <div class="card p-4 h-100 shadow-sm"
                 style="border-radius:16px;border:2px solid #e5e7eb">
              <div class="fs-1">📖</div>
              <div class="fw-bold mt-2" style="color:#0C1E7F">
                <?= e($s['name']) ?>
              </div>
              <div class="small text-muted mt-1">
                <?= e($s['class_level'] ?? $s['grade'] ?? '') ?>
              </div>
              <?php if ($active): ?>
                <div class="badge bg-success mt-2 align-self-start">✅ Unlocked</div>
              <?php else: ?>
                <div class="badge bg-secondary mt-2 align-self-start">🔒 Locked</div>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>