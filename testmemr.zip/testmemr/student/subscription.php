<?php
require_once __DIR__ . '/../includes/db.php';
$user = require_student($pdo);

/* Refresh */
$st = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$st->execute([(int)$user['id']]);
$user = $st->fetch();

/* Active grades */
$active_grades = [];
if (!empty($user['subscribed_grades'])) {
    $active_grades = array_map('trim', explode(',', $user['subscribed_grades']));
    $active_grades = array_values(array_filter($active_grades));
}
if (($user['grade'] ?? '') === 'ALL') {
    $active_grades = CLASS_LEVELS;
}

$active = is_subscribed($user);

/* Manual mode */
define('MODEMPAY_API_KEY', '');
$auto_mode = !empty(MODEMPAY_API_KEY);

$merchant_phones = [
    'Wave'      => '+220866879863',
    'Afrimoney' => '+2207705902',
    'QMoney'    => '+2207705902',
];

/* ============================================================
   HANDLE POST
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $plan_key = $_POST['plan']       ?? '';
    $grade    = trim($_POST['grade'] ?? '');
    $method   = trim($_POST['method'] ?? '');
    $ref      = trim($_POST['reference'] ?? '');
    $plan     = PLANS[$plan_key] ?? null;

    $errors = [];

    if (!$plan) $errors[] = 'Choose a valid plan.';

    if ($plan && $plan['type'] === 'single' && !in_array($grade, CLASS_LEVELS, true)) {
        $errors[] = 'Choose the grade you want to subscribe to.';
    }

    if ($method === '') $errors[] = 'Choose a payment method.';
    if ($ref === '')    $errors[] = 'Enter the reference / transaction ID.';

    if ($errors) {
        foreach ($errors as $e) flash($e, 'danger');
        redirect(SITE_URL . '/student/subscription.php');
    }

    $grades_csv = ($plan['type'] === 'all') ? implode(',', CLASS_LEVELS) : $grade;

    /* Screenshot */
    $screenshot = null;
    if (!empty($_FILES['screenshot']['tmp_name'])) {
        $dir = __DIR__ . '/../uploads';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        $ext = strtolower(pathinfo($_FILES['screenshot']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp','pdf'], true)) {
            $name = 'pay_' . $user['id'] . '_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['screenshot']['tmp_name'], $dir . '/' . $name)) {
                $screenshot = 'uploads/' . $name;
            }
        }
    }

    $pdo->prepare('INSERT INTO payments
        (user_id, plan, amount, method, reference, screenshot, status, subscribed_grades)
        VALUES (?,?,?,?,?,?,?,?)')
        ->execute([
            (int)$user['id'],
            $plan_key,
            $plan['amount'],
            $method,
            $ref,
            $screenshot,
            'pending',
            $grades_csv,
        ]);

    flash('✅ Payment submitted. Admin will approve it soon.');
    redirect(SITE_URL . '/student/subscription.php');
}

$ph = $pdo->prepare('SELECT * FROM payments WHERE user_id=? ORDER BY id DESC LIMIT 20');
$ph->execute([(int)$user['id']]);
$payments = $ph->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<style>
  .sub-banner{background:linear-gradient(135deg,#CE1126 0%,#0C1E7F 50%,#3A7728 100%);color:#fff;border-radius:20px;padding:22px;margin-bottom:20px}
  .section-title{font-weight:800;color:#0C1E7F;font-size:1.05rem;margin:24px 0 12px;padding-bottom:8px;border-bottom:3px solid #e5e7eb}

  .grade-pick{display:flex;align-items:center;gap:12px;padding:14px;border:3px solid #e5e7eb;border-radius:14px;background:#fff;cursor:pointer;transition:all .15s;width:100%;position:relative;}
  .grade-pick:hover{border-color:#0C1E7F;transform:translateY(-2px);}
  .grade-pick input{display:none;}
  .grade-pick.selected{border-color:#0C1E7F;background:linear-gradient(135deg,#eff6ff,#f0fdf4);}
  .grade-pick.owned{border-color:#3A7728;background:linear-gradient(135deg,#f0fdf4,#dcfce7);}
  .grade-pick.owned::after{content:"✓ Owned";position:absolute;top:-10px;right:14px;background:#3A7728;color:#fff;font-size:.65rem;font-weight:800;padding:3px 10px;border-radius:20px;}
  .gp-icon{font-size:1.6rem;width:46px;height:46px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:#f1f5f9;border-radius:10px;}
  .gp-title{font-weight:800;color:#0f172a;font-size:.95rem;}

  .plan-btn{background:#fff;border:3px solid #e5e7eb;border-radius:14px;padding:16px;cursor:pointer;transition:all .15s;position:relative;text-align:center;width:100%;display:block;height:100%}
  .plan-btn:hover{border-color:#0C1E7F;transform:translateY(-3px);}
  .plan-btn input{position:absolute;opacity:0}
  .plan-btn.selected{border-color:#0C1E7F;background:linear-gradient(135deg,#eff6ff,#f0fdf4);box-shadow:0 10px 24px rgba(12,30,127,.15)}
  .plan-btn .p-price{font-size:1.7rem;font-weight:900;color:#0C1E7F;line-height:1}
  .plan-btn .p-duration{font-weight:800;font-size:.9rem;margin-top:6px;color:#0f172a}
  .plan-btn .p-desc{font-size:.75rem;color:#6b7280;margin-top:4px}
  .plan-btn.best{border-color:#d97706}
  .plan-btn.best::before{content:"⭐ BEST";position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:#d97706;color:#fff;font-size:.6rem;font-weight:800;padding:3px 10px;border-radius:20px}

  .pay-btn{background:linear-gradient(135deg,#3A7728,#16a34a);border:none;color:#fff;font-weight:800;border-radius:12px;padding:16px;width:100%;font-size:1.05rem;margin-top:14px}

  .manual-numbers{background:linear-gradient(135deg,#fff 0%,#fef9c3 100%);border-radius:16px;padding:18px;border-left:5px solid #d97706}
  .manual-numbers code{background:#0C1E7F;color:#fff;padding:4px 10px;border-radius:8px;font-weight:700;font-size:.85rem}

  .hist-card{background:#fff;border-radius:14px;padding:12px 14px;margin-bottom:10px;display:flex;align-items:center;gap:12px;border-left:5px solid #0C1E7F}
  .hist-card.approved{border-left-color:#3A7728}
  .hist-card.pending{border-left-color:#d97706}
  .hist-card.rejected{border-left-color:#CE1126}
  .hist-card.failed{border-left-color:#6b7280}
</style>

<div class="container py-4" style="max-width:1000px">

  <div class="sub-banner">
    <h3 class="mb-1">💳 Subscription</h3>
    <p class="mb-0">Choose a grade → choose a plan → pay</p>
  </div>

  <?php if (!empty($active_grades)): ?>
    <div class="card p-4 mb-4 shadow-sm border-0"
         style="border-radius:16px;background:<?= $active ? 'linear-gradient(135deg,#3A7728,#16a34a)' : 'linear-gradient(135deg,#d97706,#f59e0b)' ?>;color:#fff">
      <div class="small opacity-75">Currently Subscribed</div>
      <div class="fs-5 fw-bold">
        <?= implode(' · ', array_map('e', $active_grades)) ?>
      </div>
      <?php if ($active): ?>
        <div class="small mt-1">
          Expires <?= e(fmt_date($user['subscription_end'])) ?>
          · <?= sub_days_left($user) ?> day(s) left
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data" id="subscriptionForm">

    <!-- STEP 1 — PICK A GRADE -->
    <div class="section-title">1️⃣ Pick Your Grade <span class="text-muted small">(required for One Grade plans)</span></div>

    <div class="row g-3 mb-4">
      <?php
      $grade_meta = [
        'NAT Grade 3' => '🎒',
        'NAT Grade 6' => '📘',
        'NAT Grade 8' => '🎓',
        'GABECE'      => '🏆',
      ];
      foreach (CLASS_LEVELS as $g):
        $owned = in_array($g, $active_grades, true);
      ?>
        <div class="col-6 col-md-3">
          <label class="grade-pick <?= $owned ? 'owned' : '' ?>">
            <input type="radio" name="grade" value="<?= e($g) ?>">
            <div class="gp-icon"><?= $grade_meta[$g] ?? '🎓' ?></div>
            <div class="flex-grow-1">
              <div class="gp-title"><?= e($g) ?></div>
            </div>
          </label>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- STEP 2 — ONE GRADE PLANS -->
    <div class="section-title">2️⃣ One Grade Plans <span class="text-muted small">(all subjects in the picked grade)</span></div>
    <div class="row g-2 mb-4">
      <?php foreach (PLANS as $key => $p): if ($p['type'] !== 'single') continue; ?>
        <div class="col-6 col-md-4">
          <label class="plan-btn <?= $key === 'single_month' ? 'best' : '' ?>">
            <input type="radio" name="plan" value="<?= e($key) ?>">
            <div class="p-price">D<?= (int)$p['amount'] ?></div>
            <div class="p-duration"><?= e($p['duration_label']) ?></div>
            <div class="p-desc">All subjects in 1 grade</div>
          </label>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- STEP 3 — ALL GRADES PLANS -->
    <div class="section-title">3️⃣ All Grades Plan <span class="text-muted small">(everything unlocked)</span></div>
    <div class="row g-2 mb-4">
      <?php foreach (PLANS as $key => $p): if ($p['type'] !== 'all') continue; ?>
        <div class="col-6 col-md-4">
          <label class="plan-btn">
            <input type="radio" name="plan" value="<?= e($key) ?>">
            <div class="p-price">D<?= (int)$p['amount'] ?></div>
            <div class="p-duration"><?= e($p['duration_label']) ?></div>
            <div class="p-desc">Every subject · Every grade</div>
          </label>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- STEP 4 — PAYMENT -->
    <div class="section-title">4️⃣ Payment Details</div>

    <div class="manual-numbers mb-3">
      <h6 class="fw-bold" style="color:#78350f">📞 Send payment to:</h6>
      <ul class="list-unstyled mb-0">
        <li>🌊 <b>Wave:</b> <code><?= e($merchant_phones['Wave']) ?></code></li>
        <li>📱 <b>Afrimoney:</b> <code><?= e($merchant_phones['Afrimoney']) ?></code></li>
        <li>💳 <b>QMoney:</b> <code><?= e($merchant_phones['QMoney']) ?></code></li>
      </ul>
      <p class="small text-muted mt-2 mb-0">Name: <b>Moses Ibuchim C.</b></p>
    </div>

    <div class="mb-3">
      <label class="form-label fw-bold">Method</label>
      <select name="method" class="form-select" required>
        <option value="">-- Choose --</option>
        <option>Wave</option>
        <option>QMoney</option>
        <option>Afrimoney</option>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label fw-bold">Reference / Transaction ID</label>
      <input name="reference" class="form-control" placeholder="e.g. TX123456789" required>
    </div>

    <div class="mb-3">
      <label class="form-label fw-bold">Screenshot (optional)</label>
      <input type="file" name="screenshot" class="form-control" accept="image/*,application/pdf">
    </div>

    <button type="submit" class="pay-btn">✅ Submit Payment</button>

  </form>

  <!-- Payment history -->
  <?php if ($payments): ?>
    <h5 class="mt-5 mb-3 fw-bold" style="color:#0C1E7F">📜 Payment History</h5>
    <?php foreach ($payments as $p):
      $iconMap = ['approved'=>'✅','pending'=>'⏳','rejected'=>'❌','failed'=>'⚠️','cancelled'=>'🚫'];
      $icon  = $iconMap[$p['status']] ?? '•';
      $label = PLANS[$p['plan']]['label'] ?? ($p['plan'] . ' — D' . $p['amount']);
    ?>
      <div class="hist-card <?= e($p['status']) ?>">
        <div class="fs-3"><?= $icon ?></div>
        <div class="flex-grow-1">
          <div class="fw-bold"><?= e($label) ?></div>
          <div class="small text-muted">
            <?= e($p['method']) ?> · <?= e(fmt_date($p['created_at'])) ?>
            <?php if (!empty($p['reference'])): ?> · Ref: <?= e($p['reference']) ?><?php endif; ?>
          </div>
        </div>
        <div class="fw-bold" style="color:#0C1E7F">D<?= (int)$p['amount'] ?></div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>

</div>

<script>
(function () {
  /* Grade chips */
  document.querySelectorAll('.grade-pick').forEach(function (pick) {
    pick.addEventListener('click', function () {
      document.querySelectorAll('.grade-pick').forEach(function (p) {
        p.classList.remove('selected');
      });
      pick.classList.add('selected');
      pick.querySelector('input').checked = true;
    });
  });

  /* Plan chips */
  document.querySelectorAll('.plan-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.plan-btn').forEach(function (b) {
        b.classList.remove('selected');
      });
      btn.classList.add('selected');
      btn.querySelector('input').checked = true;
    });
  });
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>