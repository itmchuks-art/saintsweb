<?php
require_once __DIR__ . '/../includes/db.php';
$user = require_student($pdo);

/* Must have chosen a grade */
if (empty($user['grade'])) {
    redirect(SITE_URL . '/student/choose_grade.php');
}

/* Already dismissed welcome? Then go on */
if (!empty($_SESSION['seen_welcome'])) {
    $dest = is_subscribed($user)
        ? SITE_URL . '/student/dashboard.php'
        : SITE_URL . '/student/subscription.php';
    redirect($dest);
}

/* Continue button pressed */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['seen_welcome'] = 1;

    $dest = is_subscribed($user)
        ? SITE_URL . '/student/dashboard.php'
        : SITE_URL . '/student/subscription.php';
    redirect($dest);
}

/* Grade info */
$active_grades = [];
if (!empty($user['subscribed_grades'])) {
    $active_grades = array_map('trim', explode(',', $user['subscribed_grades']));
    $active_grades = array_values(array_filter($active_grades));
}
if (($user['grade'] ?? '') === 'ALL') {
    $active_grades = CLASS_LEVELS;
}
if (empty($active_grades) && !empty($user['grade'])) {
    $active_grades = [$user['grade']];
}

$subscribed = is_subscribed($user);

include __DIR__ . '/../includes/header.php';
?>

<style>
  .hero{
    background:linear-gradient(135deg,#CE1126 0%,#0C1E7F 50%,#3A7728 100%);
    color:#fff;border-radius:24px;padding:40px 28px;
    position:relative;overflow:hidden;
    box-shadow:0 20px 50px rgba(12,30,127,.30);
  }
  .hero::before{content:"";position:absolute;top:-80px;right:-80px;width:260px;height:260px;border-radius:50%;background:rgba(255,255,255,.08);}
  .hero::after{content:"";position:absolute;bottom:-100px;left:-60px;width:220px;height:220px;border-radius:50%;background:rgba(255,255,255,.06);}
  .hero-flag{display:inline-flex;flex-direction:column;width:70px;height:50px;border-radius:6px;overflow:hidden;border:2px solid rgba(255,255,255,.5);box-shadow:0 6px 18px rgba(0,0,0,.25);}
  .hero-flag div{width:100%;}
  .hero-flag .f1{height:12px;background:#CE1126;}
  .hero-flag .f2{height:5px; background:#fff;}
  .hero-flag .f3{height:12px;background:#0C1E7F;}
  .hero-flag .f4{height:5px; background:#fff;}
  .hero-flag .f5{height:12px;background:#3A7728;}

  .hero h1{font-weight:900;font-size:2.1rem;line-height:1.15;margin:14px 0 8px;position:relative;z-index:2;}
  .hero p.lead{font-size:1rem;opacity:.95;margin:0;position:relative;z-index:2;}
  .hero .badge-first{display:inline-block;background:rgba(255,255,255,.2);padding:6px 14px;border-radius:20px;font-size:.75rem;font-weight:800;letter-spacing:1px;margin-top:6px;position:relative;z-index:2;}

  .feature-card{background:#fff;border-radius:16px;padding:22px;height:100%;border:2px solid #e5e7eb;transition:all .15s;}
  .feature-card:hover{border-color:#0C1E7F;transform:translateY(-3px);box-shadow:0 10px 26px rgba(12,30,127,.10);}
  .feature-icon{font-size:2.2rem;margin-bottom:8px;}
  .feature-card h6{font-weight:800;color:#0C1E7F;font-size:.95rem;margin-bottom:6px;}
  .feature-card p{font-size:.83rem;color:#4b5563;margin:0;}

  .step-row{display:flex;gap:16px;align-items:flex-start;padding:16px;background:#f8faff;border-radius:14px;margin-bottom:12px;}
  .step-num{width:40px;height:40px;flex-shrink:0;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:900;color:#fff;font-size:1rem;}
  .step-title{font-weight:800;color:#0f172a;font-size:.95rem;}
  .step-desc{font-size:.83rem;color:#6b7280;margin-top:2px;}

  .price-card{background:#fff;border:3px solid #e5e7eb;border-radius:16px;padding:20px;text-align:center;height:100%;transition:all .15s;}
  .price-card:hover{border-color:#0C1E7F;transform:translateY(-3px);box-shadow:0 10px 26px rgba(12,30,127,.10);}
  .price-card.best{border-color:#d97706;background:linear-gradient(135deg,#fff,#fef9c3);position:relative;}
  .price-card.best::before{content:"⭐ BEST";position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:#d97706;color:#fff;font-size:.65rem;font-weight:800;padding:3px 10px;border-radius:20px;}
  .price-amount{font-size:2.4rem;font-weight:900;color:#0C1E7F;line-height:1;}
  .price-period{font-weight:800;color:#0f172a;margin-top:6px;font-size:.95rem;}
  .price-desc{font-size:.75rem;color:#6b7280;margin-top:4px;}

  .grade-chip{display:inline-flex;align-items:center;gap:6px;background:#eff6ff;border:2px solid #0C1E7F;color:#0C1E7F;font-weight:700;padding:8px 16px;border-radius:20px;font-size:.85rem;margin:4px;}
  .subject-chip{display:inline-block;background:#f0fdf4;border:2px solid #3A7728;color:#3A7728;font-weight:700;padding:6px 14px;border-radius:20px;font-size:.8rem;margin:4px;}

  .cta-btn{background:linear-gradient(135deg,#3A7728,#16a34a);color:#fff;border:none;border-radius:14px;padding:18px 32px;font-weight:800;font-size:1.05rem;box-shadow:0 12px 30px rgba(58,119,40,.35);width:100%;max-width:400px;}
  .cta-btn:hover{filter:brightness(1.05);color:#fff;}
</style>

<div class="container py-4" style="max-width:900px">

  <!-- HERO -->
  <div class="hero text-center mb-4">
    <div class="hero-flag mx-auto">
      <div class="f1"></div><div class="f2"></div><div class="f3"></div>
      <div class="f4"></div><div class="f5"></div>
    </div>

    <h1>Test Me Mr 🇬🇲</h1>
    <div class="badge-first">#1 EDUCATIONAL WEB APP FOR GAMBIAN SCHOOLS</div>

    <p class="lead mt-3">
      Welcome, <b><?= e($user['name']) ?></b> 🎉<br>
      The first and best digital learning platform built <b>for Gambian school students</b>.
    </p>
  </div>

  <!-- WHAT IS IT -->
  <div class="card p-4 mb-4 shadow-sm border-0" style="border-radius:18px">
    <h5 class="fw-bold mb-3" style="color:#0C1E7F">📖 What is Test Me Mr?</h5>

    <p class="text-muted" style="font-size:.92rem">
      <b>Test Me Mr</b> is the <b>first</b> and <b>best</b> educational web app created
      specifically for students in <b>The Gambia</b>. Whether you are preparing for the
      <b>NAT (National Assessment Test)</b> for Grade 3, 6 or 8, or the
      <b>GABECE</b> exam for Grade 9, Test Me Mr gives you thousands of
      real practice questions — right on your phone, tablet or computer.
    </p>

    <p class="text-muted mb-0" style="font-size:.92rem">
      No textbooks to carry. No expensive classes. Just open the app,
      pick a subject, and start practising. You get <b>instant scores</b>,
      a <b>letter grade</b>, and a full breakdown of what you need to study — so you
      learn faster and score higher in your real exam.
    </p>
  </div>

  <!-- WHAT YOU GET -->
  <div class="card p-4 mb-4 shadow-sm border-0" style="border-radius:18px;background:linear-gradient(135deg,#eff6ff,#f0fdf4)">
    <h5 class="fw-bold mb-3" style="color:#0C1E7F">🎓 What you get</h5>

    <div class="mb-2">
      <div class="small fw-bold text-muted mb-1">📚 GRADES COVERED</div>
      <div>
        <span class="grade-chip">🎒 NAT Grade 3</span>
        <span class="grade-chip">📘 NAT Grade 6</span>
        <span class="grade-chip">🎓 NAT Grade 8</span>
        <span class="grade-chip">🏆 GABECE</span>
      </div>
    </div>

    <div class="mt-3">
      <div class="small fw-bold text-muted mb-1">📖 SUBJECTS</div>
      <div>
        <span class="subject-chip">➗ Maths</span>
        <span class="subject-chip">📝 English</span>
        <span class="subject-chip">🔬 Science</span>
        <span class="subject-chip">🌍 SES</span>
      </div>
    </div>

    <div class="mt-3 small text-muted">
      <b>6,000+ real exam questions</b> across all grades and subjects.
    </div>
  </div>

  <!-- FEATURES -->
  <h5 class="fw-bold mb-3" style="color:#0C1E7F">✨ Why Test Me Mr is the best</h5>

  <div class="row g-3 mb-4">
    <div class="col-6 col-md-4">
      <div class="feature-card">
        <div class="feature-icon">📚</div>
        <h6>Real Exam Questions</h6>
        <p>Thousands of questions built from the actual Gambian curriculum.</p>
      </div>
    </div>
    <div class="col-6 col-md-4">
      <div class="feature-card">
        <div class="feature-icon">⚡</div>
        <h6>Instant Results</h6>
        <p>See your score, mark and letter grade the moment you submit.</p>
      </div>
    </div>
    <div class="col-6 col-md-4">
      <div class="feature-card">
        <div class="feature-icon">🎯</div>
        <h6>Grades A+ to F</h6>
        <p>Know exactly where you stand before the real exam.</p>
      </div>
    </div>
    <div class="col-6 col-md-4">
      <div class="feature-card">
        <div class="feature-icon">⏱️</div>
        <h6>Optional Timer</h6>
        <p>Choose 5–25 minutes to practise under real exam pressure — or no timer at all.</p>
      </div>
    </div>
    <div class="col-6 col-md-4">
      <div class="feature-card">
        <div class="feature-icon">🔁</div>
        <h6>Unlimited Retakes</h6>
        <p>Every test pulls fresh random questions. Practise as many times as you want.</p>
      </div>
    </div>
    <div class="col-6 col-md-4">
      <div class="feature-card">
        <div class="feature-icon">📊</div>
        <h6>See What You Missed</h6>
        <p>We show you exactly which questions you failed — so you know what to study.</p>
      </div>
    </div>
  </div>

  <!-- PRICING -->
  <h5 class="fw-bold mb-3" style="color:#0C1E7F">💰 Simple Pricing — One Grade</h5>

  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <div class="price-card">
        <div class="price-amount">D25</div>
        <div class="price-period">1 Day</div>
        <div class="price-desc">All subjects in one grade</div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="price-card">
        <div class="price-amount">D75</div>
        <div class="price-period">1 Week</div>
        <div class="price-desc">All subjects in one grade</div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="price-card best">
        <div class="price-amount">D225</div>
        <div class="price-period">1 Month</div>
        <div class="price-desc">All subjects in one grade</div>
      </div>
    </div>
  </div>

  <div class="alert alert-info small mb-4">
    💡 <b>Want more grades?</b> You can add another grade at any time — just subscribe
    again and pick a different grade. Each grade is billed separately.
  </div>

  <!-- HOW TO USE -->
  <h5 class="fw-bold mb-3" style="color:#0C1E7F">🚀 How to use Test Me Mr</h5>

  <div class="mb-4">

    <div class="step-row">
      <div class="step-num" style="background:#0C1E7F">1</div>
      <div>
        <div class="step-title">Subscribe to a Grade</div>
        <div class="step-desc">
          Go to <b>Subscribe</b> in the top menu. Pick your grade (NAT Grade 3, 6, 8 or GABECE)
          and choose a plan — <b>D25 (1 day)</b>, <b>D75 (1 week)</b>, or <b>D225 (1 month)</b>.
        </div>
      </div>
    </div>

    <div class="step-row">
      <div class="step-num" style="background:#d97706">2</div>
      <div>
        <div class="step-title">Pay with Wave, Afrimoney or QMoney</div>
        <div class="step-desc">
          Send the exact amount to the number shown, upload a screenshot of your payment,
          and submit. Your account is activated once approved.
        </div>
      </div>
    </div>

    <div class="step-row">
      <div class="step-num" style="background:#3A7728">3</div>
      <div>
        <div class="step-title">Write a Test</div>
        <div class="step-desc">
          Click <b>📝 Write Test</b>. Pick a subject (Maths, English, Science or SES),
          how many questions (5, 10, 15 … 50) and optionally how much time
          (5, 10, 15 … 25 minutes). Then start.
        </div>
      </div>
    </div>

    <div class="step-row">
      <div class="step-num" style="background:#CE1126">4</div>
      <div>
        <div class="step-title">See Your Grade &amp; Keep Practising</div>
        <div class="step-desc">
          After submitting, you get your <b>score</b>, <b>mark %</b> and
          <b>letter grade (A+ to F)</b>, plus a list of the questions you failed —
          so you know what to study. Then click <b>“Test Me More, Mr!”</b> to try again with
          fresh questions.
        </div>
      </div>
    </div>

  </div>

  <!-- RULES -->
  <div class="card p-4 mb-4 shadow-sm border-0" style="border-radius:16px;border-left:5px solid #d97706">
    <h6 class="fw-bold mb-2" style="color:#78350f">📌 A few important rules</h6>
    <ul class="mb-0 small text-muted">
      <li>Your account can only be open on <b>one device</b> at a time. If someone else logs in, you'll be logged out.</li>
      <li>You can subscribe to <b>multiple grades</b> on the same account.</li>
      <li>After a test, <b>the correct answers are not shown</b> — we tell you which ones you missed so you keep practising.</li>
      <li>Payments are approved by an admin, usually within a few minutes.</li>
    </ul>
  </div>

  <!-- STATUS -->
  <?php if (!empty($active_grades) || $subscribed): ?>
    <div class="card p-4 mb-4 shadow-sm border-0"
         style="border-radius:16px;background:linear-gradient(135deg,#eff6ff,#f0fdf4)">
      <h6 class="fw-bold mb-3" style="color:#0C1E7F">📊 Your Current Status</h6>

      <div class="d-flex flex-wrap gap-4">
        <div>
          <div class="small text-muted">Subscription</div>
          <div class="fw-bold" style="color:<?= $subscribed ? '#3A7728' : '#CE1126' ?>">
            <?= $subscribed ? '✅ Active' : '❌ Not active' ?>
          </div>
        </div>

        <?php if (!empty($active_grades)): ?>
          <div>
            <div class="small text-muted">Your Grade(s)</div>
            <div class="fw-bold" style="color:#0C1E7F">
              <?= implode(' · ', array_map('e', $active_grades)) ?>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($subscribed): ?>
          <div>
            <div class="small text-muted">Days Left</div>
            <div class="fw-bold" style="color:#d97706"><?= sub_days_left($user) ?> day(s)</div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>

  <!-- CTA -->
  <div class="text-center py-3">
    <form method="post">
      <?php if ($subscribed): ?>
        <button type="submit" class="cta-btn">🚀 Start Learning Now</button>
      <?php else: ?>
        <button type="submit" class="cta-btn"
                style="background:linear-gradient(135deg,#d97706,#b45309);box-shadow:0 12px 30px rgba(217,119,6,.35)">
          💳 Subscribe Now to Start
        </button>
      <?php endif; ?>
    </form>

    <p class="text-muted small mt-3 mb-0">
      Made with ❤️ for Gambian students 🇬🇲
    </p>
  </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>